package com.hm.pnp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.hm.pnp.dbtransactionmanager.DAOBase;
import com.hm.pnp.domain.ProductAccessDomain;
import com.hm.pnp.exceptions.ConnectionNotFoundException;
import com.hm.pnp.exceptions.PNPException;
import com.hm.pnp.exceptions.Trace;
import com.hm.pnp.exceptions.UniqueKeyConstraintViolationException;



public class ProductAccessDAO extends DAOBase{
	
	private static final Logger LOGGER = Logger.getLogger(ProductAccessDAO.class);
	  private final String CLASSNAME = getClass().getName();
	  boolean debug = LOGGER.isDebugEnabled();
	  boolean error = LOGGER.isEnabledFor(Level.ERROR);

public Map<String, String> getCustomerListFrmRegisteredCust_(String reg_id) throws Exception{
		
		HashMap custmerlist = new LinkedHashMap();	
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			/*String Query = "select distinct hm_customer.CUSTOMER_NAME,HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID,HM_CUSTOMER_PRODUCT_OPTIONS.CUST_PROD_OPTION_KEY from HM_CUSTOMER_PRODUCT_OPTIONS,hm_customer " +
					       "where hm_customer.CUSTOMER_ID=HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID";*/
			String Query="select Reg_Cust_Id,CUSTOMER_ID,CUSTOMER_NAME from HM_CUST_REGISTRATION where REG_ID='"+reg_id+"' AND Status='001' order by (customer_name) asc ";
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				//proObj.setCustprodoptionKey(rs.getString("CUST_PROD_OPTION_KEY"));
				custmerlist.put((rs.getString("Reg_Cust_Id").trim()+"|"+rs.getString("CUSTOMER_NAME").trim()),rs.getString("CUSTOMER_NAME").trim());
				

			}

		} catch (Exception se) {
			
			
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					
					throw new Exception();
				}
			} 
			}
		
		return custmerlist;

	}

public Map<String, String> getProductList_() throws Exception {
	
	HashMap productlist = new LinkedHashMap();	
	//Map<String,String> custmerlist = new Orde<String,String>();
	Connection con = null;
	Statement stmt = null;

	try {
		con = getConnection();
		stmt = con.createStatement();
		/*String Query = "select distinct hm_customer.CUSTOMER_NAME,HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID,HM_CUSTOMER_PRODUCT_OPTIONS.CUST_PROD_OPTION_KEY from HM_CUSTOMER_PRODUCT_OPTIONS,hm_customer " +
				       "where hm_customer.CUSTOMER_ID=HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID";*/
		String Query="SELECT UNIQUE PRODUCT_ID,PRODUCT_NAME FROM HM_PRODUCT_PNP where PRODUCT_ID = '2' ORDER BY PRODUCT_NAME ASC";
		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			//proObj.setCustprodoptionKey(rs.getString("CUST_PROD_OPTION_KEY"));
			productlist.put(rs.getString("PRODUCT_ID").trim(),rs.getString("PRODUCT_NAME").trim() );
			

		}

	} catch (Exception se) {
		
		
		throw new Exception();
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				
				throw new Exception();
			}
		} 
		}
	
	return productlist;

}

public String productacesssave_(ProductAccessDomain prodaccessdomain) throws Exception,PNPException{
	
	String METHODNAME = "productacesssave_()";
	Connection con = null;
	
	
	
	try{
		con = getConnection();
		PreparedStatement pstmt = null;
		/*for(int i=0;i<=opstatearr.length-1;i++)
		{*/
		String fixflg=null;
		String todate=null;
		String frmdate=null;
		String cust[]=StringUtils.split(prodaccessdomain.getCustemerId(), "|");
		if(prodaccessdomain.isFixflag())
		{
			fixflg="1";
		}
		else 
		{
			fixflg="0";
		}
		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		if(prodaccessdomain.getTo_date()!=null)
	    todate=formatter.format(prodaccessdomain.getTo_date());
	    if(prodaccessdomain.getFrm_date()!=null)
	    	frmdate=formatter.format(prodaccessdomain.getFrm_date());
		
	    if(prodaccessdomain.isFixflag())
	    {
		String sqlLog = "insert into HM_PRODUCT_ACCESS(PA_ID,REG_CUST_ID,PRODUCT_ID,PRICE," +
				"FIXED_FLAG,FIXED_PRICE,FIXED_NUMBER_OF_REQUEST,VALID_UPTO,DATE_OF_REG,VALID_FROM) " +
				" values(PA_ID_SEQ.nextval,?,?,?,?,?,?,?,SYSDATE,?)";
		pstmt = con.prepareStatement(sqlLog);

		pstmt.setString(1, cust[0].trim());
		pstmt.setString(2,prodaccessdomain.getProdId().trim());
		pstmt.setString(3,prodaccessdomain.getPrice().trim());
		pstmt.setString(4,fixflg);
		pstmt.setString(5,prodaccessdomain.getFixprice().trim());
		pstmt.setString(6,prodaccessdomain.getFixrqst().trim());
		pstmt.setString(7,todate);
		pstmt.setString(8,frmdate);
	    }
	    else
	    {
	    	String sqlLog1 = "insert into HM_PRODUCT_ACCESS(PA_ID,REG_CUST_ID,PRODUCT_ID,PRICE,FIXED_FLAG,DATE_OF_REG)" +
	    			" values(PA_ID_SEQ.nextval,?,?,?,?,SYSDATE)";
	    	pstmt = con.prepareStatement(sqlLog1);

			pstmt.setString(1, cust[0].trim());
			pstmt.setString(2,prodaccessdomain.getProdId().trim());
			pstmt.setString(3,prodaccessdomain.getPrice().trim());
			pstmt.setString(4,fixflg);
	    }
				
		

		pstmt.executeUpdate();
		//}
		pstmt.close();
		System.out.println("Product Acccess Saved Sucessfully");

		

		
	}
	catch (SQLException se)
    {
	      se.printStackTrace();
	      if (1 == se.getErrorCode()) {
	    	  Trace trace = new Trace(getClass(), METHODNAME);
	        throw new UniqueKeyConstraintViolationException(
	          trace, 
	          "Already Registered Customer:",prodaccessdomain.getCustemerId());
	      }
	      LOGGER.error("Exception" + se.getMessage());
	      Trace trace = new Trace(getClass(), METHODNAME);
	      throw new PNPException(trace, 
	        "Error while register CUSTOMER information", 
	        se);
	    }
	catch (Exception e) {
		throw  new Exception("Error While Inserting Data");
	}
	finally{
		if(con!=null)
		con.close();
	}
	return "success";
	
}

public List<ProductAccessDomain> getProductList_(String custid) throws PNPException {


	String METHODNAME = "getProductList_()";
	List<ProductAccessDomain> productlist = new ArrayList<ProductAccessDomain>();
	Connection con = null;
	Statement stmt = null;

	try {
		con = getConnection();
		stmt = con.createStatement();
		String str[]=StringUtils.split(custid,"|");
		
String Query="select PRODUCT_NAME,PRODUCT_ID from hm_product_pnp " +
		"where PRODUCT_ID in(select PRODUCT_ID from Hm_Product_Access where REG_CUST_ID='"+str[0]+"' and STATUS in ('001'))";
     ProductAccessDomain proObj;
		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			proObj = new ProductAccessDomain();
			proObj.setProdname(rs.getString("PRODUCT_NAME"));
			proObj.setProdId(rs.getString("PRODUCT_ID"));
			productlist.add(proObj);

		}

	} catch (SQLException se) {
		if (error) {
			LOGGER.error("Exception" + se.getMessage());
		}
		se.printStackTrace();
		Trace trace = new Trace(this.getClass(), METHODNAME);
		throw new PNPException(trace,
				"Error while  retriving Product details List", se);
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				if (error) {
					LOGGER.error("Exception" + se.getMessage());
				}
				Trace trace = new Trace(this.getClass(), METHODNAME);
				throw new ConnectionNotFoundException(
						"Connection Not Found");
			}
		} else {
			if (debug) {
				LOGGER.debug("connection not open");
			}
		}
	}

	if (debug) {
		LOGGER.debug("Returning from " + METHODNAME + " in " + CLASSNAME);
	}
	return productlist;



}
public List<ProductAccessDomain> getProductListForModify_(String custid) throws PNPException {


	String METHODNAME = "getProductList_()";
	List<ProductAccessDomain> productlist = new ArrayList<ProductAccessDomain>();
	Connection con = null;
	Statement stmt = null;

	try {
		con = getConnection();
		stmt = con.createStatement();
		String str[]=StringUtils.split(custid,"|");
		
String Query="select PRODUCT_NAME,PRODUCT_ID from hm_product_pnp " +
		"where PRODUCT_ID in(select PRODUCT_ID from Hm_Product_Access where REG_CUST_ID='"+str[0]+"' and STATUS in ('001','002'))";
     ProductAccessDomain proObj;
		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			proObj = new ProductAccessDomain();
			proObj.setProdname(rs.getString("PRODUCT_NAME"));
			proObj.setProdId(rs.getString("PRODUCT_ID"));
			productlist.add(proObj);

		}

	} catch (SQLException se) {
		if (error) {
			LOGGER.error("Exception" + se.getMessage());
		}
		se.printStackTrace();
		Trace trace = new Trace(this.getClass(), METHODNAME);
		throw new PNPException(trace,
				"Error while  retriving Product details List", se);
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				if (error) {
					LOGGER.error("Exception" + se.getMessage());
				}
				Trace trace = new Trace(this.getClass(), METHODNAME);
				throw new ConnectionNotFoundException(
						"Connection Not Found");
			}
		} else {
			if (debug) {
				LOGGER.debug("connection not open");
			}
		}
	}

	if (debug) {
		LOGGER.debug("Returning from " + METHODNAME + " in " + CLASSNAME);
	}
	return productlist;



}
public ProductAccessDomain exctractsubproductinfo_(String prodId,
		String custemerId) throws PNPException{
	ProductAccessDomain productaccessdomain = new ProductAccessDomain();

    String METHODNAME = "exctractsubproductinfo_()";

    Connection con = null;
    Statement stmt = null;
    try
    {
      con = getConnection();
      stmt = con.createStatement();
      String str[]=StringUtils.split(custemerId, "|");
      String sqlString = "SELECT PRICE,FIXED_FLAG,FIXED_PRICE,FIXED_NUMBER_OF_REQUEST,TO_DATE(VALID_UPTO,'dd-mm-yy') VALID_UPTO,TO_DATE(VALID_FROM,'dd-mm-yy') VALID_FROM " +
      		"FROM hm_product_access WHERE PRODUCT_ID='" +prodId + "' and REG_CUST_ID='"+str[0]+"'";

      ResultSet rs = stmt.executeQuery(sqlString);
      while (rs.next()) {
    	  productaccessdomain.setPrice(rs.getString("PRICE"));
    	  if(rs.getString("FIXED_FLAG")!=null)
    	  {
        if (rs.getString("FIXED_FLAG").equalsIgnoreCase("1"))
        	productaccessdomain.setFixflag(true);
        else
        	productaccessdomain.setFixflag(false);
    	  }
        productaccessdomain.setFixprice(rs.getString("FIXED_PRICE"));
        productaccessdomain.setFixrqst(rs.getString("FIXED_NUMBER_OF_REQUEST"));
        productaccessdomain.setFrm_date(rs.getDate("VALID_FROM"));
        productaccessdomain.setTo_date(rs.getDate("VALID_UPTO"));
      }
    } catch (SQLException se) {
      if (this.error) {
        LOGGER.error("Exception" + se.getMessage());
      }
      se.printStackTrace();
      Trace trace = new Trace(getClass(), METHODNAME);
      throw new PNPException(trace, 
        "Error while inserting Contribution file information", se);
    }

    return productaccessdomain;
  }

public Map<String, String> getproductListByCusForMaintaint_(String custemerId) throws Exception {
	
	HashMap productList = new LinkedHashMap();	
	Connection con = null;
	Statement stmt = null;

	try {
		String str[]=StringUtils.split(custemerId,"|");
		con = getConnection();
		stmt = con.createStatement();
		
		String Query="select PRODUCT_NAME,PRODUCT_ID from hm_product_pnp " +
		"where PRODUCT_ID=(select PRODUCT_ID from Hm_Product_Access where REG_CUST_ID='"+str[0]+"')";

		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			productList.put(rs.getString("PRODUCT_ID").trim(),rs.getString("PRODUCT_NAME").trim());
		}

	} catch (Exception se) {
		
		
		throw new Exception();
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				
				throw new Exception();
			}
		} 
		}
	
	return productList;

}

public String productacessupdate_(ProductAccessDomain prodaccessdomain,String reg_id,String custid,String prodid) throws PNPException {
    String METHODNAME = "updaterulegrp_()";

    Connection con = null;
    PreparedStatement pst1 = null;
    PreparedStatement pstAuditLog = null;
    String sqlLog=null;
    
    
    try { 
    	String fixflg=null;
    	String todate=null;
    	String frmdate=null;
    	int prevfixcnt=0;
    	int updatedvol=0;
    	if(prodaccessdomain.isFixflag())
    	{
    		fixflg="1";
    	}
    	else 
    	{
    		fixflg="0";
    	}
    	DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");   //change format
    	if(prodaccessdomain.getTo_date()!=null)
        todate=formatter.format(prodaccessdomain.getTo_date());
        if(prodaccessdomain.getFrm_date()!=null)
        frmdate=formatter.format(prodaccessdomain.getFrm_date());
    	
    	
    	con = getConnection();
    
    sqlLog="insert into HM_PRODUCT_ACCESS_AUD(PA_ID,REG_CUST_ID,PRODUCT_ID,PRICE,FIXED_FLAG,FIXED_PRICE,FIXED_NUMBER_OF_REQUEST,VALID_UPTO,DATE_OF_REG,STATUS,REMARKS,VALID_FROM,REG_ID,DATE_TIME,AUDIT_REMARKS,CHANGE_LOG_ID)" +
	"(select PA_ID,REG_CUST_ID,PRODUCT_ID,PRICE,FIXED_FLAG,FIXED_PRICE,FIXED_NUMBER_OF_REQUEST,VALID_UPTO,DATE_OF_REG,STATUS,REMARKS,VALID_FROM,?,SYSDATE,?,PRODUCT_ACCESS_AUD_SEQ.nextval from HM_PRODUCT_ACCESS " +
	" where REG_CUST_ID='"+custid+"' and PRODUCT_ID="+prodid+")";
pstAuditLog=con.prepareStatement(sqlLog);
pstAuditLog.setString(1,reg_id);

pstAuditLog.setString(2,prodaccessdomain.getRemark());

pstAuditLog.executeUpdate();
    
    if(prodaccessdomain.isFixflag())
    {
    /*String qry="SELECT FIXED_NUMBER_OF_REQUEST FROM HM_PRODUCT_ACCESS where REG_CUST_ID='"+custid+"' and PRODUCT_ID='"+prodid+"' and STATUS=001";	
    pst1=con.prepareStatement(qry);
	ResultSet rss = pst1.executeQuery();
	
	while (rss.next()) {
		prevfixcnt=rss.getInt("FIXED_NUMBER_OF_REQUEST");
	}
	updatedvol=prevfixcnt+Integer.parseInt();*/
    	
      pst1 = con.prepareStatement("update HM_PRODUCT_ACCESS  set PRICE=?,FIXED_FLAG=?,FIXED_PRICE=?,FIXED_NUMBER_OF_REQUEST=?,VALID_UPTO=?,VALID_FROM=?,STATUS='',REMARKS='' where REG_CUST_ID='"+custid+"' and PRODUCT_ID='"+prodid+"'"); 

      pst1.setString(1,prodaccessdomain.getPrice().trim());
      pst1.setString(2,fixflg);
      pst1.setString(3,prodaccessdomain.getFixprice().trim());
      pst1.setString(4,prodaccessdomain.getFixrqst().trim());
      pst1.setString(5,todate);
      pst1.setString(6,frmdate);

      int result = pst1.executeUpdate();
      System.out.println("No of rows updated with flag True :  " + result);
      System.out.println("PNP HM_PRODUCT_ACCESS Updated Sucessfully");
    }
    else
    {
    	pst1 = con.prepareStatement("update HM_PRODUCT_ACCESS set PRICE=?,FIXED_FLAG=?,STATUS='',REMARKS='' where REG_CUST_ID='"+custid+"' and PRODUCT_ID='"+prodid+"'"); 

        pst1.setString(1,prodaccessdomain.getPrice().trim());
        pst1.setString(2,fixflg);

        int result = pst1.executeUpdate();
        System.out.println("No of rows updated with flag False :  " + result);
        System.out.println("PNP HM_PRODUCT_ACCESS Updated Sucessfully");
    }
    } catch (SQLException se)
    {
      se.printStackTrace();
     
      LOGGER.error("Exception" + se.getMessage());
      Trace trace = new Trace(getClass(), METHODNAME);
      throw new PNPException(trace, 
        "Error while updating PNP HM_PRODUCT_ACCESS information", 
        se);
    }
    finally
    {
      if (con != null) {
        try {
          pst1.close();
         /* pstAuditLog.close();*/
          con.close();
        } catch (SQLException se) {
          if (this.error) {
            LOGGER.error("Exception" + se.getMessage());
          }
          Trace trace = new Trace(getClass(), METHODNAME);
          throw new ConnectionNotFoundException(
            "Connection Not Found");
        }
      }
      else if (this.debug)
        LOGGER.debug("connection not open");
    }
    return "success";
  }

public String getReportingManager(String userId) throws Exception {
	
	Connection con = null;
	Statement stmt = null;
	String rmId = null;
	try {
		con = getConnection();
		stmt = con.createStatement();
		String q="SELECT RM_ID FROM HM_REPORTING_MANAGER WHERE RM_NAME='"+userId.toUpperCase()+"'";		//UPPER(RM_NAME)='"+userId.toUpperCase()+"'";
		//String query1="SELECT EmpCode FROM hm_user_registration WHERE userName=userId";
		//String Query="SELECT RmId FROM hm_user_registration, hm_reporting_manager WHERE hm_user_registration.Rm_Id=RmId";
		ResultSet rs = stmt.executeQuery(q);
		while(rs.next()) 
		{
			rmId=rs.getString("RM_ID");
		}

	} catch (Exception se) {
		
		
		throw new Exception();
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				
				throw new Exception();
			}
		} 
		}
	
	return rmId;

}

public List<ProductAccessDomain> getProductAccessReqList(String Rm_Id) throws Exception {
	
	List<ProductAccessDomain> prodAccessList = new ArrayList<ProductAccessDomain>();	
	//Map<String,String> custmerlist = new Orde<String,String>();
	Connection con = null;
	Statement stmt = null;

	try {
		con = getConnection();   
		stmt = con.createStatement();
		/*String Query = "select distinct hm_customer.CUSTOMER_NAME,HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID,HM_CUSTOMER_PRODUCT_OPTIONS.CUST_PROD_OPTION_KEY from HM_CUSTOMER_PRODUCT_OPTIONS,hm_customer " +
				       "where hm_customer.CUSTOMER_ID=HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID";*/
		//String Query="SELECT UNIQUE SUB_PRODUCT_KEY,PRODUCT_DESC FROM hm_products_detail ORDER BY PRODUCT_DESC ASC";
String Query= "SELECT HM_USER_REGISTRATION.EMP_NAME,HM_PRODUCT_PNP.PRODUCT_NAME,HM_PRODUCT_ACCESS.PRODUCT_ID,HM_CUST_REGISTRATION.CUSTOMER_NAME,HM_USER_REGISTRATION.EMAIL,HM_PRODUCT_ACCESS.PRICE,HM_PRODUCT_ACCESS.FIXED_FLAG,HM_PRODUCT_ACCESS.FIXED_PRICE,HM_PRODUCT_ACCESS.REG_CUST_ID,HM_PRODUCT_ACCESS.STATUS,HM_PRODUCT_ACCESS.REMARKS,HM_PRODUCT_ACCESS.FIXED_NUMBER_OF_REQUEST,To_Date(HM_PRODUCT_ACCESS.VALID_UPTO,'dd-mm-yyyy') VALID_UPTO,To_Date(HM_PRODUCT_ACCESS.VALID_FROM,'dd-mm-yyyy') VALID_FROM FROM HM_PRODUCT_PNP,HM_USER_REGISTRATION,HM_CUST_REGISTRATION,HM_PRODUCT_ACCESS WHERE HM_CUST_REGISTRATION.REG_CUST_ID=HM_PRODUCT_ACCESS.REG_CUST_ID AND HM_PRODUCT_PNP.PRODUCT_ID=HM_PRODUCT_ACCESS.PRODUCT_ID AND HM_CUST_REGISTRATION.REG_ID=HM_USER_REGISTRATION.REG_ID AND HM_PRODUCT_ACCESS.REG_CUST_ID IN (SELECT REG_CUST_ID FROM HM_CUST_REGISTRATION WHERE REG_ID IN (SELECT REG_ID FROM HM_USER_REGISTRATION WHERE RM_ID='"+Rm_Id+"'))";
		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			//we can check status here and if rejected then only add that record in trialPeriod list
			//proObj.setCustprodoptionKey(rs.getString("CUST_PROD_OPTION_KEY"));
			if(rs.getString("STATUS")!=null)
			{
			if(!rs.getString("STATUS").trim().equals("001"))
			{
			ProductAccessDomain prodAccess = new ProductAccessDomain();
			prodAccess.setEmpName(rs.getString("EMP_NAME").trim());
			prodAccess.setCustName(rs.getString("CUSTOMER_NAME").trim());
			prodAccess.setProdId(rs.getString("PRODUCT_ID").trim());
			prodAccess.setProdname(rs.getString("PRODUCT_NAME").trim());
			prodAccess.setPrice(rs.getString("PRICE").trim());
			prodAccess.setEmail(rs.getString("EMAIL").trim());
			prodAccess.setRegCustId(rs.getString("REG_CUST_ID").trim());
			if(rs.getString("FIXED_FLAG")!=null)
			{
			if(rs.getString("FIXED_FLAG").equals("1"))
			{
			prodAccess.setFixprice(rs.getString("FIXED_PRICE").trim());
			prodAccess.setFixrqst(rs.getString("FIXED_NUMBER_OF_REQUEST").trim());
			prodAccess.setFrm_date(rs.getDate("VALID_FROM"));
			prodAccess.setTo_date(rs.getDate("VALID_UPTO"));
			}
			}
            if(rs.getString("REMARKS") != null)
			prodAccess.setRemark(rs.getString("REMARKS").trim());
            if(rs.getString("STATUS")!=null)
            {
			String s=rs.getString("STATUS").trim();
		    if(s.equals("002"))
		    	prodAccess.setStatus("REJECTED");
			else prodAccess.setStatus("");
            }
            else prodAccess.setStatus("");
		    prodAccessList.add(prodAccess);
			}
			}
			else if(rs.getString("STATUS")==null)
			{
				ProductAccessDomain prodAccess = new ProductAccessDomain();
				prodAccess.setEmpName(rs.getString("EMP_NAME").trim());
				prodAccess.setCustName(rs.getString("CUSTOMER_NAME").trim());
				prodAccess.setProdId(rs.getString("PRODUCT_ID").trim());
				prodAccess.setProdname(rs.getString("PRODUCT_NAME").trim());
				prodAccess.setPrice(rs.getString("PRICE").trim());
				prodAccess.setEmail(rs.getString("EMAIL").trim());
				prodAccess.setRegCustId(rs.getString("REG_CUST_ID").trim());
				if(rs.getString("FIXED_FLAG")!=null)
				{
				if(rs.getString("FIXED_FLAG").equals("1"))
				{
				prodAccess.setFixprice(rs.getString("FIXED_PRICE").trim());
				prodAccess.setFixrqst(rs.getString("FIXED_NUMBER_OF_REQUEST").trim());
				prodAccess.setFrm_date(rs.getDate("VALID_FROM"));
				prodAccess.setTo_date(rs.getDate("VALID_UPTO"));
				}
				}
	            if(rs.getString("REMARKS") != null)
				prodAccess.setRemark(rs.getString("REMARKS").trim());
	            if(rs.getString("STATUS")!=null)
	            {
				String s=rs.getString("STATUS").trim();
			    if(s.equals("002"))
			    	prodAccess.setStatus("REJECTED");
				else prodAccess.setStatus("");
	            }
	            else prodAccess.setStatus("");
			    prodAccessList.add(prodAccess);
			}

		}

	} catch (Exception se) {
		
		se.printStackTrace();
		throw new Exception();
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				
				throw new Exception();
			}
		} 
		}
	
	return prodAccessList;

}

public List<ProductAccessDomain> getProductAccessListFiltered(String Rm_Id,String status) throws Exception {
	
	List<ProductAccessDomain> prodAccessList = new ArrayList<ProductAccessDomain>();	
	//Map<String,String> custmerlist = new Orde<String,String>();
	Connection con = null;
	Statement stmt = null;
	String st = null;
	 if(status.equalsIgnoreCase("APPROVED"))
	    {
	    	st="001";
	    }
	    else st="002";
	try {
		con = getConnection();   
		stmt = con.createStatement();
		/*String Query = "select distinct hm_customer.CUSTOMER_NAME,HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID,HM_CUSTOMER_PRODUCT_OPTIONS.CUST_PROD_OPTION_KEY from HM_CUSTOMER_PRODUCT_OPTIONS,hm_customer " +
				       "where hm_customer.CUSTOMER_ID=HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID";*/
		//String Query="SELECT UNIQUE SUB_PRODUCT_KEY,PRODUCT_DESC FROM hm_products_detail ORDER BY PRODUCT_DESC ASC";
String Query= "SELECT HM_USER_REGISTRATION.EMP_NAME,HM_PRODUCT_PNP.PRODUCT_NAME,HM_PRODUCT_ACCESS.PRODUCT_ID,HM_PRODUCT_ACCESS.REG_CUST_ID,HM_CUST_REGISTRATION.CUSTOMER_NAME,HM_USER_REGISTRATION.EMAIL,HM_PRODUCT_ACCESS.PRICE,HM_PRODUCT_ACCESS.FIXED_FLAG,HM_PRODUCT_ACCESS.FIXED_PRICE,HM_PRODUCT_ACCESS.FIXED_NUMBER_OF_REQUEST,HM_PRODUCT_ACCESS.STATUS,HM_PRODUCT_ACCESS.REMARKS,To_Date(HM_PRODUCT_ACCESS.VALID_UPTO,'dd-mm-yyyy') VALID_UPTO,To_Date(HM_PRODUCT_ACCESS.VALID_FROM,'dd-mm-yyyy') VALID_FROM FROM HM_PRODUCT_PNP,HM_USER_REGISTRATION,HM_CUST_REGISTRATION,HM_PRODUCT_ACCESS WHERE HM_CUST_REGISTRATION.REG_CUST_ID=HM_PRODUCT_ACCESS.REG_CUST_ID AND HM_PRODUCT_PNP.PRODUCT_ID=HM_PRODUCT_ACCESS.PRODUCT_ID AND HM_CUST_REGISTRATION.REG_ID=HM_USER_REGISTRATION.REG_ID AND HM_PRODUCT_ACCESS.STATUS ='"+st+"' AND HM_PRODUCT_ACCESS.REG_CUST_ID IN (SELECT REG_CUST_ID FROM HM_CUST_REGISTRATION WHERE REG_ID IN (SELECT REG_ID FROM HM_USER_REGISTRATION WHERE RM_ID='"+Rm_Id+"'))";
		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			//we can check status here and if rejected then only add that record in trialPeriod list
			//proObj.setCustprodoptionKey(rs.getString("CUST_PROD_OPTION_KEY"));
			ProductAccessDomain prodAccess = new ProductAccessDomain();
			prodAccess.setEmpName(rs.getString("EMP_NAME").trim());
			prodAccess.setCustName(rs.getString("CUSTOMER_NAME").trim());
			prodAccess.setProdId(rs.getString("PRODUCT_ID").trim());
			prodAccess.setProdname(rs.getString("PRODUCT_NAME").trim());
			prodAccess.setPrice(rs.getString("PRICE").trim());
			prodAccess.setEmail(rs.getString("EMAIL").trim());
			prodAccess.setRegCustId(rs.getString("REG_CUST_ID").trim());
			if(rs.getString("FIXED_FLAG")!=null)
			{
			if(rs.getString("FIXED_FLAG").equals("1"))
			{
			prodAccess.setFixprice(rs.getString("FIXED_PRICE").trim());
			prodAccess.setFixrqst(rs.getString("FIXED_NUMBER_OF_REQUEST").trim());
			prodAccess.setFrm_date(rs.getDate("VALID_FROM"));
			prodAccess.setTo_date(rs.getDate("VALID_UPTO"));
			}
			}
			if(rs.getString("REMARKS")!=null)
			prodAccess.setRemark(rs.getString("REMARKS").trim());
			if(rs.getString("STATUS")!=null)
			{
			String s=rs.getString("STATUS").trim();
			if(s.equals("001"))
		    	prodAccess.setStatus("APPROVED");
			else if(s.equals("002"))
		    	prodAccess.setStatus("REJECTED");
			else prodAccess.setStatus("");
			}
			else prodAccess.setStatus("");
		    prodAccessList.add(prodAccess);

		}

	} catch (Exception se) {
		
		
		throw new Exception();
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				
				throw new Exception();
			}
		} 
		}
	
	return prodAccessList;

}

public boolean updateReqStatus(String regCustId,String changeToStatus,String productID,String remark) throws Exception {
	
	Connection con = null;
	//Statement stmt = null;
	java.sql.PreparedStatement stmt = null;
	String q = "";

	try {
		con = getConnection();
		
		if(changeToStatus.equalsIgnoreCase("APPROVE"))
		{
			//q="UPDATE HM_USER_REGISTRATION SET STATUS='001',remark='"+remark+"',UPDATE_DATE=SYSDATE WHERE EMP_code='"+empCode+"'";
			q="UPDATE HM_PRODUCT_ACCESS SET STATUS='001',REMARKS='"+remark+"' WHERE REG_CUST_ID='"+regCustId+"' AND PRODUCT_ID='"+productID+"'";
		}
		else 
		{
	    	//q="UPDATE HM_USER_REGISTRATION SET STATUS='002',remark='"+remark+"',UPDATE_DATE=SYSDATE WHERE EMP_code='"+empCode+"'";
	    	q="UPDATE HM_PRODUCT_ACCESS SET STATUS='002',REMARKS='"+remark+"' WHERE REG_CUST_ID='"+regCustId+"' AND PRODUCT_ID='"+productID+"'";
		}
		stmt = con.prepareStatement(q);
		//String query1="SELECT EmpCode FROM hm_user_registration WHERE userName=userId";
		//String Query="SELECT RmId FROM hm_user_registration, hm_reporting_manager WHERE hm_user_registration.Rm_Id=RmId";
		stmt.executeUpdate();

	} catch (Exception se) {
		
		
		throw new Exception();
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				
				throw new Exception();
			}
		} 
		}
	return true;

}

public List<ProductAccessDomain> getPinListByStateForPinRqst_(String stateid) throws PNPException {


	String METHODNAME = "getPinListByStateForPinRqst_()";
	List<ProductAccessDomain> pinlist = new ArrayList<ProductAccessDomain>();
	Connection con = null;
	Statement stmt = null;

	try {
		con = getConnection();
		stmt = con.createStatement();
		
		
String Query="select distinct PIN_CODE || '|' as PIN_CODE from  hm_pin_pnp_test where state_code='"+stateid+"'";
     ProductAccessDomain proObj;
		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			proObj = new ProductAccessDomain();
			proObj.setPincode(rs.getString("PIN_CODE"));
			
			pinlist.add(proObj);

		}

	} catch (SQLException se) {
		if (error) {
			LOGGER.error("Exception" + se.getMessage());
		}
		se.printStackTrace();
		Trace trace = new Trace(this.getClass(), METHODNAME);
		throw new PNPException(trace,
				"Error while  retriving PinCode  List", se);
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				if (error) {
					LOGGER.error("Exception" + se.getMessage());
				}
				Trace trace = new Trace(this.getClass(), METHODNAME);
				throw new ConnectionNotFoundException(
						"Connection Not Found");
			}
		} else {
			if (debug) {
				LOGGER.debug("connection not open");
			}
		}
	}

	if (debug) {
		LOGGER.debug("Returning from " + METHODNAME + " in " + CLASSNAME);
	}
	return pinlist;



}

public List<ProductAccessDomain> getDistListByState_(String stateid) throws PNPException {


	String METHODNAME = "getPinListByStateForPinRqst_()";
	List<ProductAccessDomain> distlist = new ArrayList<ProductAccessDomain>();
	Connection con = null;
	Statement stmt = null;
	try {
		con = getConnection();
		stmt = con.createStatement();
		
		
String Query="select distinct DISTRICT from  hm_pin_pnp_test where state_code='"+stateid+"' ORDER BY DISTRICT";
     ProductAccessDomain proObj;
		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			
			proObj = new ProductAccessDomain();
			proObj.setDistrict(rs.getString("DISTRICT"));
			
			distlist.add(proObj);

		}

	} catch (SQLException se) {
		if (error) {
			LOGGER.error("Exception" + se.getMessage());
		}
		se.printStackTrace();
		Trace trace = new Trace(this.getClass(), METHODNAME);
		throw new PNPException(trace,
				"Error while  retriving District  List", se);
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				if (error) {
					LOGGER.error("Exception" + se.getMessage());
				}
				Trace trace = new Trace(this.getClass(), METHODNAME);
				throw new ConnectionNotFoundException(
						"Connection Not Found");
			}
		} else {
			if (debug) {
				LOGGER.debug("connection not open");
			}
		}
	}

	if (debug) {
		LOGGER.debug("Returning from " + METHODNAME + " in " + CLASSNAME);
	}
	return distlist;



}

public List<ProductAccessDomain> getpinListByDistrictForPinRqst_(String distid) throws PNPException {


	String METHODNAME = "getPinListByStateForPinRqst_()";
	List<ProductAccessDomain> pinlist = new ArrayList<ProductAccessDomain>();
	Connection con = null;
	Statement stmt = null;

	try {
		con = getConnection();
		stmt = con.createStatement();
		if(StringUtils.isNotBlank(distid))
			distid=StringUtils.removeStart(distid, ",").trim();
		distid=StringUtils.removeStart(distid, "|").trim();
		distid=StringUtils.removeStart(distid, ",").trim();
String Query="select distinct PIN_CODE || '|' as PIN_CODE from  hm_pin_pnp_test where district in("+distid+")";
     ProductAccessDomain proObj;
		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			proObj = new ProductAccessDomain();
			proObj.setPincode(rs.getString("PIN_CODE"));
			
			pinlist.add(proObj);

		}

	} catch (SQLException se) {
		if (error) {
			LOGGER.error("Exception" + se.getMessage());
		}
		se.printStackTrace();
		Trace trace = new Trace(this.getClass(), METHODNAME);
		throw new PNPException(trace,
				"Error while  retriving PinCode  List", se);
	}

	finally {
		if (con != null) {
			try {
				stmt.close();
				con.close();
			} catch (SQLException se) {
				if (error) {
					LOGGER.error("Exception" + se.getMessage());
				}
				Trace trace = new Trace(this.getClass(), METHODNAME);
				throw new ConnectionNotFoundException(
						"Connection Not Found");
			}
		} else {
			if (debug) {
				LOGGER.debug("connection not open");
			}
		}
	}

	if (debug) {
		LOGGER.debug("Returning from " + METHODNAME + " in " + CLASSNAME);
	}
	return pinlist;



}


}
