package com.hm.pnp.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlRowSetResultSetExtractor;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet;



import com.hm.pnp.exceptions.ConnectionNotFoundException;
import com.hm.pnp.exceptions.PNPException;
import com.hm.pnp.exceptions.Trace;
import com.hm.pnp.exceptions.UniqueKeyConstraintViolationException;
import com.hm.pnp.dbtransactionmanager.DAOBase;
import com.hm.pnp.domain.CustomerRegistration;
import com.hm.pnp.domain.ProductAccessDomain;

public class MemberSetupDAO extends  DAOBase{
	
	
	private static final Logger LOGGER = Logger.getLogger(MemberSetupDAO.class);
	  private final String CLASSNAME = getClass().getName();
	  boolean debug = LOGGER.isDebugEnabled();
	  boolean error = LOGGER.isEnabledFor(Level.ERROR);
	  
	  private final static String OUT_PARAM_1 = "pv_error"; // OUT
	  private final static String OUT_PARAM_1_AS_CURSOR = "pt_ref_cursor";  //out as cursor

	public Map<String, String> getCustomerList_() throws Exception{
		
		HashMap custmerlist = new LinkedHashMap();	
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			/*String Query = "select distinct hm_customer.CUSTOMER_NAME,HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID,HM_CUSTOMER_PRODUCT_OPTIONS.CUST_PROD_OPTION_KEY from HM_CUSTOMER_PRODUCT_OPTIONS,hm_customer " +
					       "where hm_customer.CUSTOMER_ID=HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID";*/
			String Query="select CUSTOMER_ID,CUSTOMER_NAME from hm_customer order by (customer_name) asc";
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				//proObj.setCustprodoptionKey(rs.getString("CUST_PROD_OPTION_KEY"));
				custmerlist.put((rs.getString("CUSTOMER_ID").trim()+"|"+rs.getString("CUSTOMER_NAME").trim().toUpperCase()),rs.getString("CUSTOMER_NAME").trim().toUpperCase() );
				

			}

		} catch (Exception se) {
			
			se.printStackTrace();
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					
					throw new Exception();
				}
			} 
			}
		
		return custmerlist;

	}

	public Map<String, String> getStateList_() throws Exception{
		
		HashMap statelist = new LinkedHashMap();	
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			/*String Query = "select distinct hm_customer.CUSTOMER_NAME,HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID,HM_CUSTOMER_PRODUCT_OPTIONS.CUST_PROD_OPTION_KEY from HM_CUSTOMER_PRODUCT_OPTIONS,hm_customer " +
					       "where hm_customer.CUSTOMER_ID=HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID";*/
			String Query="SELECT UNIQUE STATE_CODE,STATE_NAME FROM HM_STATE ORDER BY STATE_NAME ASC";
			//String Query="select distinct hm_pin_pnp_test .state_code as STATE_CODE, hm_state.STATE_NAME as STATE_NAME from hm_state,hm_pin_pnp_test  where hm_state.state_code=hm_pin_pnp_test .state_code order by state_name";
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				//proObj.setCustprodoptionKey(rs.getString("CUST_PROD_OPTION_KEY"));
				statelist.put(rs.getString("STATE_CODE").trim(),rs.getString("STATE_NAME").trim() );
				

			}

		} catch (Exception se) {
			
			se.printStackTrace();
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					se.printStackTrace();
					throw new Exception();
				}
			} 
			}
		
		return statelist;

	}
public Map<String, String> getStateListFromDump_() throws Exception{
		
		HashMap statelist = new LinkedHashMap();	
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			/*String Query = "select distinct hm_customer.CUSTOMER_NAME,HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID,HM_CUSTOMER_PRODUCT_OPTIONS.CUST_PROD_OPTION_KEY from HM_CUSTOMER_PRODUCT_OPTIONS,hm_customer " +
					       "where hm_customer.CUSTOMER_ID=HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID";*/
			//String Query="SELECT UNIQUE STATE_CODE,STATE_NAME FROM HM_STATE ORDER BY STATE_NAME ASC";
			String Query="select distinct hm_pin_pnp_test .state_code as STATE_CODE, hm_state.STATE_NAME as STATE_NAME from hm_state,hm_pin_pnp_test  where hm_state.state_code=hm_pin_pnp_test .state_code order by state_name";
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				//proObj.setCustprodoptionKey(rs.getString("CUST_PROD_OPTION_KEY"));
				statelist.put(rs.getString("STATE_CODE").trim(),rs.getString("STATE_NAME").trim() );
				

			}

		} catch (Exception se) {
			
			se.printStackTrace();
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					se.printStackTrace();
					throw new Exception();
				}
			} 
			}
		
		return statelist;

	}
	public String exctractId_(String username) throws Exception{
		
		String reg_id=null;	
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			String Query="SELECT REG_ID FROM HM_USER_REGISTRATION WHERE UPPER(HM_USER_REGISTRATION.USER_NAME) like UPPER('"+username+"')";
			
			
			
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				reg_id=rs.getString("REG_ID").trim();
			}

		} catch (Exception se) {
			
			se.printStackTrace();
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					
					throw new Exception();
				}
			} 
			}
		
		return reg_id;

	}
	
	public String getReportingManager(String userId) throws Exception {
		
		Connection con = null;
		Statement stmt = null;
		String rmId = null;
		try {
			con = getConnection();
			stmt = con.createStatement();
			String q="SELECT RM_ID FROM HM_REPORTING_MANAGER WHERE RM_NAME='"+userId.toUpperCase()+"'";
			//String query1="SELECT EmpCode FROM hm_user_registration WHERE userName=userId";
			//String Query="SELECT RmId FROM hm_user_registration, hm_reporting_manager WHERE hm_user_registration.Rm_Id=RmId";
			ResultSet rs = stmt.executeQuery(q);
			while(rs.next()) 
			{
				rmId=rs.getString("RM_ID");
			}

		} catch (Exception se) {
			
			se.printStackTrace();
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					
					throw new Exception();
				}
			} 
			}
		
		return rmId;

	}

public String addcustomer_(String reg_id, CustomerRegistration custreg) throws Exception,PNPException{
		
		String METHODNAME = "addcustomer_()";
		Connection con = null;
		String opstatearr[]=null;
		String opstate=null;
		String str1="";
		if(StringUtils.isNotBlank(custreg.getOperationalState()))
			opstate=StringUtils.removeStart(custreg.getOperationalState(), "-1,").trim();
		
		opstatearr=StringUtils.split(opstate, ",");
		for(String str:opstatearr)
			str1=str1+","+str.trim();
		
		str1=StringUtils.removeStart(str1, ",");
		
		try{
			con = getConnection();
			PreparedStatement pstmt = null;
			/*for(int i=0;i<=opstatearr.length-1;i++)
			{*/
			
			String sqlLog = "insert into HM_CUST_REGISTRATION(REG_CUST_ID,REG_ID,CUSTOMER_ID,CUSTOMER_NAME," +
					"OPERATIONAL_STATE,HEAD_OFFICE_ADDRESS,HEAD_OFFICE_STATE,DATE_OF_REG,STATUS) " +
					" values(REG_CUST_ID_SEQ.nextval,?,?,?,?,?,?,SYSDATE,'001')";
			pstmt = con.prepareStatement(sqlLog);

			pstmt.setString(1, reg_id);
			pstmt.setString(2,custreg.getCustId().trim());
			pstmt.setString(3,custreg.getCustName().trim());
			pstmt.setString(4,str1.trim());
			pstmt.setString(5,custreg.getHeadOfficeAddress().trim() );
			pstmt.setString(6,custreg.getHeadOfficeState().trim());
			

			pstmt.executeUpdate();
			//}
			pstmt.close();
			System.out.println("CUSTOMER Saved Sucessfully");

			

			
		}
		catch (SQLException se)
	    {
		      se.printStackTrace();
		      if (1 == se.getErrorCode()) {
		    	  Trace trace = new Trace(getClass(), METHODNAME);
		        throw new UniqueKeyConstraintViolationException(
		          trace, 
		          "Already Registered Customer:",custreg.getCustName());
		      }
		      LOGGER.error("Exception" + se.getMessage());
		      Trace trace = new Trace(getClass(), METHODNAME);
		      throw new PNPException(trace, 
		        "Error while register CUSTOMER information", 
		        se);
		    }
		catch (Exception e) {
			e.printStackTrace();
			throw  new Exception("Error While Inserting Data");
		}
		finally{
			if(con!=null)
			con.close();
		}
		return "success";
		
	}

	public Map<String, String> getProductList_() throws Exception {
		
		HashMap productlist = new LinkedHashMap();	
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			/*String Query = "select distinct hm_customer.CUSTOMER_NAME,HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID,HM_CUSTOMER_PRODUCT_OPTIONS.CUST_PROD_OPTION_KEY from HM_CUSTOMER_PRODUCT_OPTIONS,hm_customer " +
					       "where hm_customer.CUSTOMER_ID=HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID";*/
			String Query="SELECT UNIQUE PRODUCT_ID,PRODUCT_NAME FROM HM_PRODUCT_PNP ORDER BY PRODUCT_NAME ASC";
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				//proObj.setCustprodoptionKey(rs.getString("CUST_PROD_OPTION_KEY"));
				productlist.put(rs.getString("PRODUCT_ID").trim(),rs.getString("PRODUCT_NAME").trim() );
				

			}

		} catch (Exception se) {
			
			se.printStackTrace();
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					
					throw new Exception();
				}
			} 
			}
		
		return productlist;

	}

	public Map<String, String> getCustomerListFrmRegisteredCust_(String reg_id) throws Exception{
		
		HashMap custmerlist = new LinkedHashMap();	
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			/*String Query = "select distinct hm_customer.CUSTOMER_NAME,HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID,HM_CUSTOMER_PRODUCT_OPTIONS.CUST_PROD_OPTION_KEY from HM_CUSTOMER_PRODUCT_OPTIONS,hm_customer " +
					       "where hm_customer.CUSTOMER_ID=HM_CUSTOMER_PRODUCT_OPTIONS.CUSTOMER_ID";*/
			//String Query="select Reg_Cust_Id,CUSTOMER_ID,CUSTOMER_NAME from HM_CUST_REGISTRATION where REG_ID='"+reg_id+"' AND Status='001' order by (customer_name) asc ";
			//String Query="select REG_ID, Reg_Cust_Id,CUSTOMER_ID,CUSTOMER_NAME from HM_CUST_REGISTRATION where REG_ID in (select REG_ID from HM_USER_REGISTRATION where RM_ID='"+Rm_Id+"') AND Status='001' order by (customer_name) asc";
			
			/*ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				//proObj.setCustprodoptionKey(rs.getString("CUST_PROD_OPTION_KEY"));
				custmerlist.put((rs.getString("Reg_Cust_Id").trim()+"|"+rs.getString("CUSTOMER_NAME").trim()),rs.getString("CUSTOMER_NAME").trim());
				

			}
*/
			ResultSet rs=null;
			DataSource dataSource = getDataSource();
			CustomerListProcedure sproc = new CustomerListProcedure(
					dataSource);
          

			Map<?, ?> l_parameterMap = sproc.setParameters(reg_id);
			Map<?, ?> results = sproc.execute(l_parameterMap);

			if (null != results) {

				rs = ((ResultSetWrappingSqlRowSet) results
						.get(OUT_PARAM_1_AS_CURSOR)).getResultSet();
				String str1 =  (String) results.get(OUT_PARAM_1);
				if(null !=rs )
				{
					if(StringUtils.equalsIgnoreCase(str1, "SUCCESSFUL"))
					{
						
							//int len = rs.getMetaData().getColumnCount();
							//for (int i = 1; i <= len; i++) {
								//custmerlist.put((rs.getString("CUSTOMER_ID").trim()+"|"+rs.getString("CUSTOMER_NAME").trim()),rs.getString("CUSTOMER_NAME").trim());
							//}
					while(rs.next())
					{
						custmerlist.put((rs.getString("REG_CUST_ID").trim()+"|"+rs.getString("CUSTOMER_NAME").trim().toUpperCase()),rs.getString("CUSTOMER_NAME").trim().toUpperCase());
					}
						
					}
					else
					{
						throw new Exception("Error While Fetching Data From PROC.");
					}
				}
			}
			/*CallableStatement cStmt =con.prepareCall("{CALL HMCORE.PR_PNP_CUST_ID(?)}");
	          cStmt.setInt(1, Integer.parseInt(reg_id));
	          cStmt.execute();
	          ResultSet rs1 = cStmt.getResultSet();
	          while (rs1.next()) {
	               System.out.println(rs1.getString("CUSTOMER_ID") + " "
	                         + rs1.getString("CUSTOMER_NAME"));
	          }
	          rs1.close();*/

			
			
		} catch (Exception se) {
			
			se.printStackTrace();
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					
					throw new Exception();
				}
			} 
			}
		
		return custmerlist;

	}

	public String exctractregcustId_(String cid) throws Exception{
		
		String cust_reg_id=null;	
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			String Query="SELECT REG_CUST_ID FROM HM_CUST_REGISTRATION WHERE CUSTOMER_ID='"+cid+"'";
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				cust_reg_id=rs.getString("Reg_Cust_Id").trim();
			}

		} catch (Exception se) {
			
			se.printStackTrace();
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					
					throw new Exception();
				}
			} 
			}
		
		return cust_reg_id;

	}

	public String savetrialpd_(String reg_cust_id, String pid,Date frm_date, Date to_date, String volume) throws Exception,PNPException
	{
		String METHODNAME = "savetrialpd_()";
		Connection con = null;
		try
		{
			con = getConnection();
			PreparedStatement pstmt = null;
			String sqlLog = "INSERT INTO HM_TRIAL_PERIOD_TBL(TP_ID,PRODUCT_ID,REG_CUST_ID,TRIAL_PERIOD,FROM_DATE,TO_DATE,VOLUME,DATE_OF_REG) " +
							"values(TP_ID_SEQ.nextval,?,?,?,?,?,?,SYSDATE)";
			pstmt = con.prepareStatement(sqlLog);
			
			DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		    String fromDate=formatter.format(frm_date);
		    String toDate=formatter.format(to_date);
		   	pstmt.setString(1,pid);
			pstmt.setString(2,reg_cust_id);
			pstmt.setString(3,"1" );    //is this field going to be updated after RM approval...?
			pstmt.setString(4,fromDate);
			pstmt.setString(5,toDate);
			pstmt.setString(6,volume );
					
			pstmt.executeUpdate();
			pstmt.close();
			System.out.println("Trial Period Registred Sucessfully");
		}
		catch (SQLException se)
	    {
		      se.printStackTrace();
		      if (1 == se.getErrorCode()) 
		      {
		    	  Trace trace = new Trace(getClass(), METHODNAME);
		    	  throw new UniqueKeyConstraintViolationException(trace,"Trial Period Already Registred","");
		      }
		      LOGGER.error("Exception" + se.getMessage());
		      Trace trace = new Trace(getClass(), METHODNAME);
		      throw new PNPException(trace,"Error while register Trial Period information",se);
		}
		catch (Exception e) 
		{
			 e.printStackTrace();
			throw  new Exception("Error While Inserting Data");
		}
		finally
		{
			if(con!=null)
			con.close();
		}
		return "success";
	}
		
	public String exctractrmEmail_(String username) throws Exception{
		
		String emailid=null;	
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			String Query="SELECT EMAIL_ID FROM HM_REPORTING_MANAGER WHERE RM_ID=(SELECT distinct RM_ID from HM_USER_REGISTRATION WHERE UPPER(USER_NAME)=UPPER('"+username+"'))";
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				emailid=rs.getString("EMAIL_ID").trim();
			}

		} catch (Exception se) {
			se.printStackTrace();
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					
					throw new Exception();
				}
			} 
			}
		
		return emailid;

	}
	
	public boolean validatecustomer_(String custId,String reg_id) throws Exception {
		
		String emailid=null;
		//Map<String,String> custmerlist = new Orde<String,String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			String Query="SELECT * FROM Hm_Cust_Registration WHERE CUSTOMER_ID='"+custId+"'";
			ResultSet rs = stmt.executeQuery(Query);
			while(rs.next())
			{
				return false;
			}
			

		} catch (Exception se) {
			
			
			throw new Exception();
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					
					throw new Exception();
				}
			} 
			}
		return true;

	}

	public CustomerRegistration exctractcustinfo_(String custName) throws PNPException {
		CustomerRegistration custreg = new CustomerRegistration();

	    String METHODNAME = "exctractcustinfo_()";

	    Connection con = null;
	    Statement stmt = null;
	    String id=null;
	   List<String> multipleoperationalState = new ArrayList();
	    try
	    {
	      con = getConnection();
	      stmt = con.createStatement();
	      String str[]=StringUtils.split(custName, "|");
	      String sqlString = "SELECT OPERATIONAL_STATE,HEAD_OFFICE_ADDRESS,HEAD_OFFICE_STATE FROM " +
	      		"HM_CUST_REGISTRATION WHERE REG_CUST_ID='" +str[0] + "'";

	      ResultSet rs = stmt.executeQuery(sqlString);
	      while (rs.next()) {
	    	  custreg.setOperationalState(rs.getString("OPERATIONAL_STATE"));
	    	 
	    	  custreg.setHeadOfficeAddress(rs.getString("HEAD_OFFICE_ADDRESS"));
	       
	    	  custreg.setHeadOfficeState(rs.getString("HEAD_OFFICE_STATE"));
	    	  
	    	 id=rs.getString("OPERATIONAL_STATE");
	    	  
	      }
	      if(StringUtils.isNotBlank(id))
	      {
	      String str1[]=StringUtils.split(id, ",");
	      for(String id1:str1)
	      multipleoperationalState.add(id1);
	      }
	     custreg.setMultipleoperationalState(multipleoperationalState);
	    } catch (SQLException se) {
	      if (this.error) {
	        LOGGER.error("Exception" + se.getMessage());
	      }
	      se.printStackTrace();
	      Trace trace = new Trace(getClass(), METHODNAME);
	      throw new PNPException(trace, 
	        "Error while inserting Contribution file information", se);
	    }

	    return custreg;
	  }

	public String updatecustomer_(String reg_id, CustomerRegistration custreg,String remark) throws PNPException {
	    String METHODNAME = "updatecustomer__()";

	    Connection con = null;
	    PreparedStatement pst1 = null;
	    PreparedStatement pstAuditLog = null;
	    String sqlLog=null;
	    String opstate=null;
	    String opstatearr[];
	    try { 
	    	con = getConnection();
	    
	    sqlLog="insert into HM_CUST_REGISTRATION_AUD(REG_CUST_ID,REG_ID,CUSTOMER_ID,CUSTOMER_NAME,OPERATIONAL_STATE,HEAD_OFFICE_ADDRESS,HEAD_OFFICE_STATE,DATE_OF_REG,STATUS,REMARKS,DATE_TIME,AUDIT_REMARKS,CHANGE_LOG_ID)" +
		"(select REG_CUST_ID,REG_ID,CUSTOMER_ID,CUSTOMER_NAME,OPERATIONAL_STATE,HEAD_OFFICE_ADDRESS,HEAD_OFFICE_STATE,DATE_OF_REG,STATUS,REMARKS,SYSDATE,?,REG_CUST_ID_AUD_SEQ.nextval from Hm_Cust_Registration " +
		" where REG_CUST_ID='"+custreg.getCustId()+"')";
	pstAuditLog=con.prepareStatement(sqlLog);
	pstAuditLog.setString(1,remark);

	pstAuditLog.executeUpdate();
	    
	String str1="";
	if(StringUtils.isNotBlank(custreg.getOperationalState()))
		opstate=StringUtils.removeStart(custreg.getOperationalState(), "-1,").trim();
	
	opstatearr=StringUtils.split(opstate, ",");
	for(String str:opstatearr)
		str1=str1+","+str.trim();
	
	str1=StringUtils.removeStart(str1, ",");
	      pst1 = con.prepareStatement("update Hm_Cust_Registration set OPERATIONAL_STATE=?,HEAD_OFFICE_ADDRESS=?,HEAD_OFFICE_STATE=? where REG_CUST_ID='"+custreg.getCustId()+"'"); 

	      pst1.setString(1,str1.trim());
	      pst1.setString(2,custreg.getHeadOfficeAddress().trim());
	      pst1.setString(3,custreg.getHeadOfficeState().trim());
	     

	      int result = pst1.executeUpdate();
	      System.out.println("No of rows updated with flag True :  " + result);
	      System.out.println("PNP Hm_Cust_Registration Updated Sucessfully");
	   
	    } catch (SQLException se)
	    {
	      se.printStackTrace();
	     
	      LOGGER.error("Exception" + se.getMessage());
	      Trace trace = new Trace(getClass(), METHODNAME);
	      throw new PNPException(trace, 
	        "Error while updating PNP Hm_Cust_Registration information", 
	        se);
	    }
	    finally
	    {
	      if (con != null) {
	        try {
	          pst1.close();
	         /* pstAuditLog.close();*/
	          con.close();
	        } catch (SQLException se) {
	          if (this.error) {
	            LOGGER.error("Exception" + se.getMessage());
	          }
	          Trace trace = new Trace(getClass(), METHODNAME);
	          throw new ConnectionNotFoundException(
	            "Connection Not Found");
	        }
	      }
	      else if (this.debug)
	        LOGGER.debug("connection not open");
	    }
	    return "success";
	  }
	private class CustomerListProcedure extends StoredProcedure {

		private static final String PROC_NAME = "HMCORE.PR_PNP_CUST_ID"; // Store
																								// name

		private final static String IN_PARAM_1 = "pn_reg_id"; // IN
		

		public CustomerListProcedure(DataSource ds) {
			setDataSource(ds);
			setSql(PROC_NAME);

			declareParameter(new SqlParameter(IN_PARAM_1, Types.NUMERIC));
			declareParameter(new SqlOutParameter(OUT_PARAM_1, Types.VARCHAR));
			declareParameter(new SqlOutParameter(OUT_PARAM_1_AS_CURSOR,OracleTypes.CURSOR, new SqlRowSetResultSetExtractor()));
			

			compile();
		}

		public Map<?, ?> setParameters(String inParam1) {
			HashMap<String, Object> inParams = new HashMap<String, Object>();
			if ("".equals(StringUtils.isBlank(inParam1))) {
				inParams.put(IN_PARAM_1, 0);
			} else {
				inParams.put(IN_PARAM_1, Integer.parseInt(inParam1));
			}
			
			return inParams;
		}
	}

}
