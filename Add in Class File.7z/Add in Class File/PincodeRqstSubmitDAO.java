package com.hm.pnp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlRowSetResultSetExtractor;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;


import com.hm.pnp.dbtransactionmanager.ConnectionManager;
import com.hm.pnp.dbtransactionmanager.DAOBase;
import com.hm.pnp.domain.PnpCountDomain;
import com.hm.pnp.domain.PnpReportDomain;
import com.hm.pnp.domain.ProductAccessDomain;
import com.hm.pnp.exceptions.ConnectionNotFoundException;
import com.hm.pnp.exceptions.PNPException;
import com.hm.pnp.exceptions.Trace;
import com.hm.pnp.exceptions.UniqueKeyConstraintViolationException;

public class PincodeRqstSubmitDAO extends DAOBase{

	private static final Logger LOGGER = Logger.getLogger(PincodeRqstSubmitDAO.class);
	  private final String CLASSNAME = getClass().getName();
	  boolean debug = LOGGER.isDebugEnabled();
	  boolean error = LOGGER.isEnabledFor(Level.ERROR);
	  private final static String OUT_PARAM_1 = "pv_pin_match"; // OUT
	  private final static String OUT_PARAM_2 = "pv_pin_notmatch"; // OUT
	  private final static String OUT_PARAM_1_AS_CURSOR = "CUR_MATCH";
	  private final static String OUT_PARAM_2_AS_CURSOR = "CUR_UNMATCH";
	
	public List<PnpReportDomain> savepinrqst_(String reg_id, String institutename,
			String pincode, String price,String pid,String freecnt,String dist,String state, Connection con) throws Exception {
		
		String METHODNAME = "savepinrqst_()";
		//Connection con = getConnection();
		con.setAutoCommit(false);
		String pinrqst[]=null;
		String validpinrqst[]=null;
		String invalidpinrqst[]=null;
		int pnpcnt=0;
		int free=Integer.parseInt(freecnt);
		String validpin="";
		String invalidpin="";
		String pincodematch=null;
		PreparedStatement pstUpdate = null;
		String pinlist="";
		
		if(StringUtils.isBlank(state) && StringUtils.isBlank(dist))
		{
		if(StringUtils.isNotBlank(pincode))
		{
			DataSource dataSource = getDataSource();
			PincodeListProcedure sproc = new PincodeListProcedure(dataSource);
			Map<?, ?> l_parameterMap = sproc.setParameters(pincode,institutename);
			Map<?, ?> results = sproc.execute(l_parameterMap);
			if (null != results) {
				pincodematch =  (String) results.get(OUT_PARAM_1);
				pincode=(String)results.get(OUT_PARAM_2);
				}
		}
		}
		else
		{
			DataSource dataSource = getDataSource();
			PincodeListProcedureForStaeDist sproc = new PincodeListProcedureForStaeDist(dataSource);
			Map<?, ?> l_parameterMap = sproc.setParametersForStateDist(dist,state,institutename);
			Map<?, ?> results = sproc.execute(l_parameterMap);
			ResultSet rs1=null;
			ResultSet rs2=null;
			if (null != results) {
				String str="|";
				String str1="|";
				rs1 = ((ResultSetWrappingSqlRowSet) results
						.get(OUT_PARAM_1_AS_CURSOR)).getResultSet();
				rs2 = ((ResultSetWrappingSqlRowSet) results
						.get(OUT_PARAM_2_AS_CURSOR)).getResultSet();
				if(null !=rs1 )
				{
					while(rs1.next())
					{
						//custmerlist.put((rs.getString("REG_CUST_ID").trim()+"|"+rs.getString("CUSTOMER_NAME").trim()),rs.getString("CUSTOMER_NAME").trim());
						str=str+rs1.getString("PIN_CODE").trim();
											
					}
					pincodematch=str;
					pincodematch=StringUtils.removeStart(pincodematch,"|");
				}
				if(null !=rs2 )
				{
					while(rs2.next())
					{
						//custmerlist.put((rs.getString("REG_CUST_ID").trim()+"|"+rs.getString("CUSTOMER_NAME").trim()),rs.getString("CUSTOMER_NAME").trim());
						str1=str1+rs2.getString("PIN_CODE").trim();
											
					}
					pincode=str1;
					pincode=StringUtils.removeStart(pincode,"|");
				}
				}
		}
		
		System.out.println("Pincodes Not in pinrqst tbl: "+pincode);
		System.out.println("Pincodes in pinrqst tbl: "+pincodematch);
		if(StringUtils.isNotBlank(pincodematch) && StringUtils.isNotBlank(pincode))
		pinlist=pincodematch+pincode;
		else if(StringUtils.isBlank(pincodematch) && StringUtils.isNotBlank(pincode))
			pinlist=pincode;
		else
			pinlist=pincodematch;
			//write proc code here
		
		List<PnpReportDomain> pnpdataList =new ArrayList<PnpReportDomain>();
		int i = 0;
		try{
			//con = getConnection();
			PreparedStatement pstmt = null;
			if(StringUtils.isNotBlank(pincode))
			{	
				pinrqst=StringUtils.split(pincode, "|");
			
			
			int cnt=0;
			
			for(i=0;i<=pinrqst.length-1;i++)
			{
				PreparedStatement stmt = null;
				String Query="select * from hm_pin_pnp_test where PIN_CODE='"+pinrqst[i]+"'";
				stmt=con.prepareStatement(Query);
				ResultSet rs = stmt.executeQuery();
				
				while (rs.next()) {
					cnt++;
				}
				if(cnt>0)
				{
					validpin=validpin+","+pinrqst[i];
					cnt=0;
				}
				else if(cnt==0)
				{
					invalidpin=invalidpin+","+pinrqst[i];
				}
				rs.close();
				stmt.close();
			}
			validpin=StringUtils.removeStart(validpin, ",");
			invalidpin=StringUtils.removeStart(invalidpin, ",");
			validpinrqst=StringUtils.split(validpin, ",");
			invalidpinrqst=StringUtils.split(invalidpin, ",");
			Date dt=new Date();
			Calendar cal = Calendar.getInstance();
			String month=new SimpleDateFormat("MMM").format(cal.getTime());
			String yr=new SimpleDateFormat("yyyy").format(cal.getTime());
			String totvol=null;
			
			for(i=0;i<=validpinrqst.length-1;i++)
			{
			if(free!=0)
			{
			String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
					"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
			pstmt = con.prepareStatement(sqlLog);

			pstmt.setInt(1, Integer.parseInt(reg_id));
			pstmt.setString(2,institutename);
			pstmt.setString(3,validpinrqst[i]);
			pstmt.setInt(4,1);	
			
			pstmt.setString(5,"0");
			pstmt.setString(6,month+"-"+yr);
			
			pstmt.executeUpdate();
			free--;
			if(free==0)
			{
				pstmt = con.prepareStatement("UPDATE HM_TRIAL_PERIOD_TBL SET TRIAL_PERIOD=0 WHERE REG_CUST_ID='"+institutename+"' and PRODUCT_ID='"+pid+"'");
				pstmt.executeUpdate();
				pstmt.close();	
			}
			}
			else
			{
			String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
			"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
	pstmt = con.prepareStatement(sqlLog);

	pstmt.setInt(1, Integer.parseInt(reg_id));
	pstmt.setString(2,institutename);
	pstmt.setString(3,validpinrqst[i]);
	pstmt.setInt(4,1);	
	
	pstmt.setString(5,price);
	pstmt.setString(6,month+"-"+yr);
	
	pstmt.executeUpdate();
	pstmt.close();
			}
			}
			for(i=0;i<=invalidpinrqst.length-1;i++)
			{
			
			String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
					"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
			pstmt = con.prepareStatement(sqlLog);

			pstmt.setInt(1, Integer.parseInt(reg_id));
			pstmt.setString(2,institutename);
			pstmt.setString(3,invalidpinrqst[i]);
			pstmt.setInt(4,0);			
			pstmt.setString(5,price);
			pstmt.setString(6,month+"-"+yr);
			
			pstmt.executeUpdate();
			pstmt.close();
			}
			
		
			}
			ResultSet rs=null;
			if(StringUtils.isNotBlank(pinlist) && StringUtils.isBlank(state) && StringUtils.isBlank(dist))
			{
			
				pinlist=pinlist.replace("|", ",");
				pinlist=StringUtils.removeEnd(pinlist, ",");
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where Pin_code in("+pinlist+") and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			rs = object.getResultSet();
			}
			else if(StringUtils.isNotBlank(state) && StringUtils.isNotBlank(dist) && !StringUtils.equalsIgnoreCase(state, "S"))
			{
				
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where district in("+dist+") and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			rs = object.getResultSet();
			}
			else if(StringUtils.isNotBlank(state) && StringUtils.isNotBlank(dist) && StringUtils.equalsIgnoreCase(state, "S"))
			{
				
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where state_code in('"+dist+"') and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			rs = object.getResultSet();
			}
			while(rs.next())
			{
				//Date dt=formatter.parse(rs.getString("OLDEST_LOAN"));
				PnpReportDomain pnpdomain = new PnpReportDomain();
				pnpdomain.setDistrict(rs.getString("DISTRICT"));
				pnpdomain.setPincode(rs.getString("PIN_CODE"));
				pnpdomain.setStatecode(rs.getString("STATE_CODE"));
				pnpdomain.setTotalmfis(rs.getString("TOTAL_MFIS"));
				pnpdomain.setTotal_act_mfi(rs.getString("TOTAL_ACTIV_MFI"));
				pnpdomain.setTot_center(rs.getString("TOTAL_CENTERS"));
				pnpdomain.setTot_borowers(rs.getString("TOTAL_BORROWERS"));
				pnpdomain.setTot_act_borowers(rs.getString("TOTAL_ACTIV_BORROWERS"));
				pnpdomain.setTot_overdue_borrowers(rs.getString("TOTAL_OVERDUE_BORROWERS"));
				pnpdomain.setTot_active_loans(rs.getString("TOTAL_ACTIV_LOANS"));
				pnpdomain.setTot_active_dis_amnt(rs.getString("TOTAL_ACTIV_DISBURSED_AMOUNT"));
				pnpdomain.setTot_active_out_amnt(rs.getString("TOTAL_ACTIV_OUTSTANDING_AMOUNT"));
				pnpdomain.setTot_overdue_amnt(rs.getString("TOTAL_OVERDUE_AMOUNT"));
				pnpdomain.setAvg_loan(rs.getString("AVG_LOAN"));
				pnpdomain.setTotal_closed_loan(rs.getString("TOTAL_CLOSED_LOANS"));
				pnpdomain.setOldest_loan(rs.getString("OLDEST_LOAN"));
				pnpdomain.setTotal_loan_overdue(rs.getString("TOTAL_LOANS_OVERDUE"));
				pnpdomain.setTotal_loan_dpd_0(rs.getString("TOTAL_LOAN_DPD_0"));
				pnpdomain.setTotal_loan_dpd_1_30(rs.getString("TOTAL_LOAN_DPD_1_30"));
				pnpdomain.setTotal_loan_dpd_31_60(rs.getString("TOTAL_LOAN_DPD_31_60"));
				pnpdomain.setTotal_loan_dpd_61_90(rs.getString("TOTAL_LOAN_DPD_61_90"));
				pnpdomain.setPortfolio_overdue(rs.getString("PORTFOLIO_OVERDUE"));
				pnpdomain.setPortfolio_overdue_dpd_0(rs.getString("PORTFOLIO_OVERDUE_DPD_0"));
				pnpdomain.setPortfolio_overdue_dpd_1_30(rs.getString("PORTFOLIO_OVERDUE_DPD_1_30"));
				pnpdomain.setPortfolio_overdue_dpd_31_60(rs.getString("PORTFOLIO_OVERDUE_DPD_31_60"));
				pnpdomain.setPortfolio_overdue_dpd_61_90(rs.getString("PORTFOLIO_OVERDUE_DPD_61_90"));
				pnpdomain.setTot_write_off_loan(rs.getString("TOTAL_WRITE_OFF_LOANS"));
				pnpdomain.setTot_write_off_amnt(rs.getString("TOTAL_WRITE_OFF_AMT"));
				pnpdomain.setBorrow_in_ln_cycle_1(rs.getString("BORRWER_IN_LN_CYCLE_1"));
				pnpdomain.setBorrow_in_ln_cycle_2(rs.getString("BORRWER_IN_LN_CYCLE_2"));
				pnpdomain.setBorrow_in_ln_cycle_3_grtr(rs.getString("BORRWER_IN_LN_CYCLE_3_GRTR"));
				pnpdomain.setTot_ind_ln(rs.getString("TOTAL_IND_LN"));
				pnpdomain.setTot_ind_overdue_ln(rs.getString("TOTAL_IND_OVERDUE_LN"));
				pnpdomain.setInd_ln_overdue_amnt(rs.getString("IND_LN_OVERDUE_AMT"));
				pnpdomain.setTot_grp_ln(rs.getString("TOTAL_GROUP_LN"));
				pnpdomain.setTot_grp_overdue_ln(rs.getString("TOTAL_GROUP_OVERDUE_LN"));
				pnpdomain.setGrp_ln_overdue_amnt(rs.getString("GROUP_LN_OVERDUE_AMT"));
				pnpdomain.setBorrowers(rs.getString("BORROWERS"));
				pnpdomain.setBorrowers_na(rs.getString("BORROWER_NA"));
				pnpdomain.setBorrowers_0_5k(rs.getString("BORROWER_0_5K"));
				pnpdomain.setBorrowers_5k_10k(rs.getString("BORROWER_5K_10K"));
				pnpdomain.setBorrowers_10k_15k(rs.getString("BORROWER_10K_15K"));
				pnpdomain.setBorrowers_15k_50k(rs.getString("BORROWER_15K_50K"));
				pnpdomain.setBorrowers_50k_1lac(rs.getString("BORROWER_50K_1LACS"));
				pnpdomain.setBorrowers_grt_1lac(rs.getString("BORROWER_GRTR_1LACS"));
				pnpdomain.setInstlmnt_amnt(rs.getString("INSTALLMENT_AMT"));
				pnpdomain.setInstlmnt_0_6_0_15k(rs.getString("INSTALL_0_6_0_15K"));
				pnpdomain.setInstlmnt_0_6_15k_35k(rs.getString("INSTALL_0_6_15K_35K"));
				pnpdomain.setInstlmnt_0_6_35k_50k(rs.getString("INSTALL_0_6_35K_50K"));
				pnpdomain.setInstlmnt_0_6_grt_50k(rs.getString("INSTALL_0_6_GRTR_50K"));
				pnpdomain.setInstlmnt_7_12_0_15k(rs.getString("INSTALL_7_12_0_15K"));
				pnpdomain.setInstlmnt_7_12_15k_35k(rs.getString("INSTALL_7_12_15K_35K"));
				pnpdomain.setInstlmnt_7_12_35k_50k(rs.getString("INSTALL_7_12_35K_50K"));
				pnpdomain.setInstlmnt_7_12_grt_50k(rs.getString("INSTALL_7_12_GRTR_50K"));
				pnpdomain.setInstlmnt_13_24_0_15k(rs.getString("INSTALL_13_24_0_15K"));
				pnpdomain.setInstlmnt_13_24_15k_35k(rs.getString("INSTALL_13_24_15K_35K"));
				pnpdomain.setInstlmnt_13_24_35k_50k(rs.getString("INSTALL_13_24_35K_50K"));
				pnpdomain.setInstlmnt_13_24_grt_50k(rs.getString("INSTALL_13_24_GRTR_50K"));
				pnpdomain.setInstlmnt_grtr24_0_15k(rs.getString("INSTALL_GRTR24_0_15K"));
				pnpdomain.setInstlmnt_grtr24_15k_35k(rs.getString("INSTALL_GRTR24_15K_35K"));
				pnpdomain.setInstlmnt_grtr24_35k_50k(rs.getString("INSTALL_GRTR24_35K_50K"));
				pnpdomain.setInstlmnt_grtr24_grtr_50k(rs.getString("INSTALL_GRTR24_GRTR_50K"));
				pnpdomain.setLn_cycle(rs.getString("LN_CYCLE"));
				pnpdomain.setLn_1_0_15k(rs.getString("LN_1_0_15K"));
				pnpdomain.setLn_1_15k_35k(rs.getString("LN_1_15K_35K"));
				pnpdomain.setLn_1_35k_50k(rs.getString("LN_1_35K_50K"));
				pnpdomain.setLn_1_grtr_50k(rs.getString("LN_1_GRTR_50K"));
				pnpdomain.setLn_2_0_15k(rs.getString("LN_2_0_15K"));
				pnpdomain.setLn_2_15k_35k(rs.getString("LN_2_15K_35K"));
				pnpdomain.setLn_2_35k_50k(rs.getString("LN_2_35K_50K"));
				pnpdomain.setLn_2_grtr_50k(rs.getString("LN_2_GRTR_50K"));
				pnpdomain.setLn_gtrt3_0_15k(rs.getString("LN_GRTR3_0_15K"));
				pnpdomain.setLn_grtr3_15k_35k(rs.getString("LN_GRTR3_15K_35K"));
				pnpdomain.setLn_grtr3_35k_50k(rs.getString("LN_GRTR3_35K_50K"));
				pnpdomain.setLn_grtr3_grtr_50k(rs.getString("LN_GRTR3_GRTR_50K"));
				pnpdomain.setOverlap(rs.getString("OVERLAP"));
				pnpdomain.setOut_of_complince(rs.getString("OUT_OF_COMPLIANCE"));
				pnpdomain.setmFI2(rs.getString("MFI2"));
				pnpdomain.setmFI3(rs.getString("MFI3"));
				pnpdomain.setmFI4(rs.getString("MFI4"));
				pnpdomain.setNo_of_defualts(rs.getString("NO_OF_DEFAULTS"));
				pnpdomain.setMfi_grt_4(rs.getString("MFI_GRTR_4"));
				pnpdomain.setLn_grt_50k(rs.getString("LN_GRTR_50K"));
				pnpdomain.setLoan_purpose(rs.getString("LOAN_PURPOSE"));
				pnpdomain.setLn_purpose_na(rs.getString("LN_PURPOSE_NA"));
				pnpdomain.setLn_purpose_income(rs.getString("LN_PURPOSE_INCOME"));
				pnpdomain.setLn_purpose_edu(rs.getString("LN_PURPOSE_EDU"));
				pnpdomain.setLn_purpose_house(rs.getString("LN_PURPOSE_HOUSE"));
				pnpdomain.setLn_purpose_auto(rs.getString("LN_PURPOSE_AUTOMOBILE"));
				pnpdomain.setLn_purpose_realestate(rs.getString("LN_PURPOSE_REALESTATE"));
				pnpdomain.setLn_purpose_others(rs.getString("LN_PURPOSE_OTHERS"));
				pnpdomain.setOccupation(rs.getString("OCCUPATION"));
				pnpdomain.setOccupation_na(rs.getString("OCCUPATION_NA"));
				pnpdomain.setOccupation_agri(rs.getString("OCCUPATION_AGRI"));
				pnpdomain.setOccupation_contract_emp(rs.getString("OCCUPATION_CONTRACT_EMP"));
				pnpdomain.setOccupation_self_emp(rs.getString("OCCUPATION_SELF_EMP"));
				pnpdomain.setOccupation_emp(rs.getString("OCCUPATION_EMP"));
				pnpdomain.setOccupation_others(rs.getString("OCCUPATION_OTHERS"));
				pnpdomain.setTotal_loan_dpd_current(rs.getString("TOTAL_LOAN_DPD_CURRENT"));
				pnpdomain.setTotal_loan_dpd_91_180(rs.getString("TOTAL_LOAN_DPD_91_180"));
				pnpdomain.setTotal_loan_dpd_grtr180(rs.getString("TOTAL_LOAN_DPD_GRTR180"));
				pnpdomain.setAmount_overdue(rs.getString("AMOUNT_OVERDUE"));
				pnpdomain.setAmount_overdue_dpd_0(rs.getString("AMOUNT_OVERDUE_DPD_0"));
				pnpdomain.setAmount_overdue_dpd_1_30(rs.getString("AMOUNT_OVERDUE_DPD_1_30"));
				pnpdomain.setAmount_overdue_dpd_31_60(rs.getString("AMOUNT_OVERDUE_DPD_31_60"));
				pnpdomain.setAmount_overdue_dpd_61_90(rs.getString("AMOUNT_OVERDUE_DPD_61_90"));
				pnpdomain.setAmount_overdue_dpd_91_180(rs.getString("AMOUNT_OVERDUE_DPD_91_180"));
				pnpdomain.setAmount_overdue_dpd_grtr180(rs.getString("AMOUNT_OVERDUE_DPD_GRTR180"));
				pnpdomain.setPortfolio_overdue_dpd_current(rs.getString("PORTFOLIO_OVERDUE_DPD_CURRENT"));
				pnpdomain.setPortfolio_overdue_dpd_91_180(rs.getString("PORTFOLIO_OVERDUE_DPD_91_180"));
				pnpdomain.setPortfolio_overdue_dpd_grtr180(rs.getString("PORTFOLIO_OVERDUE_DPD_GRTR180"));
				pnpdomain.setTotal_shg_ln(rs.getString("TOTAL_SHG_LN"));
				pnpdomain.setTotal_shg_overdue_ln(rs.getString("TOTAL_SHG_OVERDUE_LN"));
				pnpdomain.setShg_ln_overdue_amt(rs.getString("SHG_LN_OVERDUE_AMT"));
				pnpdataList.add(pnpdomain);
			}
			
			if(pstmt!=null)
			pstmt.close();
			System.out.println("Requested Pincode Saved Sucessfully");
			//con.commit();
			
			

			
		}
		catch (SQLException se)
	    {
		      se.printStackTrace();
		      con.rollback();
		      if (1 == se.getErrorCode()) {
		    	  Trace trace = new Trace(getClass(), METHODNAME);
				throw new UniqueKeyConstraintViolationException(
		          trace, 
		          "Already Registered Pincode:",validpinrqst[i]);
		      }
		      LOGGER.error("Exception" + se.getMessage());
		      Trace trace = new Trace(getClass(), METHODNAME);
		      throw new PNPException(trace, 
		        "Error while register pincode rqst information", 
		        se);
		    }
		catch (Exception e) {
			con.rollback();
			e.printStackTrace();
			throw  new Exception("Error While Inserting Data");
		}
		/*finally{
			if(con!=null)
			con.close();
		}*/
		return pnpdataList;
		
	}

	public List<PnpReportDomain> exctractrqstlist_(String reg_id, String institutename,
			String pincode) throws Exception {
		
		Connection con = null;
	
		String pincodematch=null;
        String pinlist="";
        List<PnpReportDomain> pnpdataList =new ArrayList<PnpReportDomain>();
		if(StringUtils.isNotBlank(pincode))
		{
			DataSource dataSource = getDataSource();
			PincodeListProcedure sproc = new PincodeListProcedure(dataSource);
			Map<?, ?> l_parameterMap = sproc.setParameters(pincode,institutename);
			Map<?, ?> results = sproc.execute(l_parameterMap);
			if (null != results) {
				pincodematch =  (String) results.get(OUT_PARAM_1);
				pincode=(String)results.get(OUT_PARAM_2);
				}
		}
		System.out.println("Pincodes Not in pinrqst tbl: "+pincode);
		System.out.println("Pincodes in pinrqst tbl: "+pincodematch);
		if(StringUtils.isNotBlank(pincodematch) && StringUtils.isNotBlank(pincode))
			pinlist=pincodematch+pincode;
			else if(StringUtils.isBlank(pincodematch) && StringUtils.isNotBlank(pincode))
				pinlist=pincode;
			else
				pinlist=pincodematch;
		
		try{
			con = getConnection();
		
			if(StringUtils.isNotBlank(pinlist))
			{
				
				pinlist=pinlist.replace("|", ",");
				pinlist=StringUtils.removeEnd(pinlist, ",");
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where Pin_code in("+pinlist+") and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			ResultSet rs = object.getResultSet();
			while(rs.next())
			{
				//Date dt=formatter.parse(rs.getString("OLDEST_LOAN"));
				PnpReportDomain pnpdomain = new PnpReportDomain();
				pnpdomain.setDistrict(rs.getString("DISTRICT"));
				pnpdomain.setPincode(rs.getString("PIN_CODE"));
				pnpdomain.setStatecode(rs.getString("STATE_CODE"));
				pnpdomain.setTotalmfis(rs.getString("TOTAL_MFIS"));
				pnpdomain.setTotal_act_mfi(rs.getString("TOTAL_ACTIV_MFI"));
				pnpdomain.setTot_center(rs.getString("TOTAL_CENTERS"));
				pnpdomain.setTot_borowers(rs.getString("TOTAL_BORROWERS"));
				pnpdomain.setTot_act_borowers(rs.getString("TOTAL_ACTIV_BORROWERS"));
				pnpdomain.setTot_overdue_borrowers(rs.getString("TOTAL_OVERDUE_BORROWERS"));
				pnpdomain.setTot_active_loans(rs.getString("TOTAL_ACTIV_LOANS"));
				pnpdomain.setTot_active_dis_amnt(rs.getString("TOTAL_ACTIV_DISBURSED_AMOUNT"));
				pnpdomain.setTot_active_out_amnt(rs.getString("TOTAL_ACTIV_OUTSTANDING_AMOUNT"));
				pnpdomain.setTot_overdue_amnt(rs.getString("TOTAL_OVERDUE_AMOUNT"));
				pnpdomain.setAvg_loan(rs.getString("AVG_LOAN"));
				pnpdomain.setTotal_closed_loan(rs.getString("TOTAL_CLOSED_LOANS"));
				pnpdomain.setOldest_loan(rs.getString("OLDEST_LOAN"));
				pnpdomain.setTotal_loan_overdue(rs.getString("TOTAL_LOANS_OVERDUE"));
				pnpdomain.setTotal_loan_dpd_0(rs.getString("TOTAL_LOAN_DPD_0"));
				pnpdomain.setTotal_loan_dpd_1_30(rs.getString("TOTAL_LOAN_DPD_1_30"));
				pnpdomain.setTotal_loan_dpd_31_60(rs.getString("TOTAL_LOAN_DPD_31_60"));
				pnpdomain.setTotal_loan_dpd_61_90(rs.getString("TOTAL_LOAN_DPD_61_90"));
				pnpdomain.setPortfolio_overdue(rs.getString("PORTFOLIO_OVERDUE"));
				pnpdomain.setPortfolio_overdue_dpd_0(rs.getString("PORTFOLIO_OVERDUE_DPD_0"));
				pnpdomain.setPortfolio_overdue_dpd_1_30(rs.getString("PORTFOLIO_OVERDUE_DPD_1_30"));
				pnpdomain.setPortfolio_overdue_dpd_31_60(rs.getString("PORTFOLIO_OVERDUE_DPD_31_60"));
				pnpdomain.setPortfolio_overdue_dpd_61_90(rs.getString("PORTFOLIO_OVERDUE_DPD_61_90"));
				pnpdomain.setTot_write_off_loan(rs.getString("TOTAL_WRITE_OFF_LOANS"));
				pnpdomain.setTot_write_off_amnt(rs.getString("TOTAL_WRITE_OFF_AMT"));
				pnpdomain.setBorrow_in_ln_cycle_1(rs.getString("BORRWER_IN_LN_CYCLE_1"));
				pnpdomain.setBorrow_in_ln_cycle_2(rs.getString("BORRWER_IN_LN_CYCLE_2"));
				pnpdomain.setBorrow_in_ln_cycle_3_grtr(rs.getString("BORRWER_IN_LN_CYCLE_3_GRTR"));
				pnpdomain.setTot_ind_ln(rs.getString("TOTAL_IND_LN"));
				pnpdomain.setTot_ind_overdue_ln(rs.getString("TOTAL_IND_OVERDUE_LN"));
				pnpdomain.setInd_ln_overdue_amnt(rs.getString("IND_LN_OVERDUE_AMT"));
				pnpdomain.setTot_grp_ln(rs.getString("TOTAL_GROUP_LN"));
				pnpdomain.setTot_grp_overdue_ln(rs.getString("TOTAL_GROUP_OVERDUE_LN"));
				pnpdomain.setGrp_ln_overdue_amnt(rs.getString("GROUP_LN_OVERDUE_AMT"));
				pnpdomain.setBorrowers(rs.getString("BORROWERS"));
				pnpdomain.setBorrowers_na(rs.getString("BORROWER_NA"));
				pnpdomain.setBorrowers_0_5k(rs.getString("BORROWER_0_5K"));
				pnpdomain.setBorrowers_5k_10k(rs.getString("BORROWER_5K_10K"));
				pnpdomain.setBorrowers_10k_15k(rs.getString("BORROWER_10K_15K"));
				pnpdomain.setBorrowers_15k_50k(rs.getString("BORROWER_15K_50K"));
				pnpdomain.setBorrowers_50k_1lac(rs.getString("BORROWER_50K_1LACS"));
				pnpdomain.setBorrowers_grt_1lac(rs.getString("BORROWER_GRTR_1LACS"));
				pnpdomain.setInstlmnt_amnt(rs.getString("INSTALLMENT_AMT"));
				pnpdomain.setInstlmnt_0_6_0_15k(rs.getString("INSTALL_0_6_0_15K"));
				pnpdomain.setInstlmnt_0_6_15k_35k(rs.getString("INSTALL_0_6_15K_35K"));
				pnpdomain.setInstlmnt_0_6_35k_50k(rs.getString("INSTALL_0_6_35K_50K"));
				pnpdomain.setInstlmnt_0_6_grt_50k(rs.getString("INSTALL_0_6_GRTR_50K"));
				pnpdomain.setInstlmnt_7_12_0_15k(rs.getString("INSTALL_7_12_0_15K"));
				pnpdomain.setInstlmnt_7_12_15k_35k(rs.getString("INSTALL_7_12_15K_35K"));
				pnpdomain.setInstlmnt_7_12_35k_50k(rs.getString("INSTALL_7_12_35K_50K"));
				pnpdomain.setInstlmnt_7_12_grt_50k(rs.getString("INSTALL_7_12_GRTR_50K"));
				pnpdomain.setInstlmnt_13_24_0_15k(rs.getString("INSTALL_13_24_0_15K"));
				pnpdomain.setInstlmnt_13_24_15k_35k(rs.getString("INSTALL_13_24_15K_35K"));
				pnpdomain.setInstlmnt_13_24_35k_50k(rs.getString("INSTALL_13_24_35K_50K"));
				pnpdomain.setInstlmnt_13_24_grt_50k(rs.getString("INSTALL_13_24_GRTR_50K"));
				pnpdomain.setInstlmnt_grtr24_0_15k(rs.getString("INSTALL_GRTR24_0_15K"));
				pnpdomain.setInstlmnt_grtr24_15k_35k(rs.getString("INSTALL_GRTR24_15K_35K"));
				pnpdomain.setInstlmnt_grtr24_35k_50k(rs.getString("INSTALL_GRTR24_35K_50K"));
				pnpdomain.setInstlmnt_grtr24_grtr_50k(rs.getString("INSTALL_GRTR24_GRTR_50K"));
				pnpdomain.setLn_cycle(rs.getString("LN_CYCLE"));
				pnpdomain.setLn_1_0_15k(rs.getString("LN_1_0_15K"));
				pnpdomain.setLn_1_15k_35k(rs.getString("LN_1_15K_35K"));
				pnpdomain.setLn_1_35k_50k(rs.getString("LN_1_35K_50K"));
				pnpdomain.setLn_1_grtr_50k(rs.getString("LN_1_GRTR_50K"));
				pnpdomain.setLn_2_0_15k(rs.getString("LN_2_0_15K"));
				pnpdomain.setLn_2_15k_35k(rs.getString("LN_2_15K_35K"));
				pnpdomain.setLn_2_35k_50k(rs.getString("LN_2_35K_50K"));
				pnpdomain.setLn_2_grtr_50k(rs.getString("LN_2_GRTR_50K"));
				pnpdomain.setLn_gtrt3_0_15k(rs.getString("LN_GRTR3_0_15K"));
				pnpdomain.setLn_grtr3_15k_35k(rs.getString("LN_GRTR3_15K_35K"));
				pnpdomain.setLn_grtr3_35k_50k(rs.getString("LN_GRTR3_35K_50K"));
				pnpdomain.setLn_grtr3_grtr_50k(rs.getString("LN_GRTR3_GRTR_50K"));
				pnpdomain.setOverlap(rs.getString("OVERLAP"));
				pnpdomain.setOut_of_complince(rs.getString("OUT_OF_COMPLIANCE"));
				pnpdomain.setmFI2(rs.getString("MFI2"));
				pnpdomain.setmFI3(rs.getString("MFI3"));
				pnpdomain.setmFI4(rs.getString("MFI4"));
				pnpdomain.setNo_of_defualts(rs.getString("NO_OF_DEFAULTS"));
				pnpdomain.setMfi_grt_4(rs.getString("MFI_GRTR_4"));
				pnpdomain.setLn_grt_50k(rs.getString("LN_GRTR_50K"));
				pnpdomain.setLoan_purpose(rs.getString("LOAN_PURPOSE"));
				pnpdomain.setLn_purpose_na(rs.getString("LN_PURPOSE_NA"));
				pnpdomain.setLn_purpose_income(rs.getString("LN_PURPOSE_INCOME"));
				pnpdomain.setLn_purpose_edu(rs.getString("LN_PURPOSE_EDU"));
				pnpdomain.setLn_purpose_house(rs.getString("LN_PURPOSE_HOUSE"));
				pnpdomain.setLn_purpose_auto(rs.getString("LN_PURPOSE_AUTOMOBILE"));
				pnpdomain.setLn_purpose_realestate(rs.getString("LN_PURPOSE_REALESTATE"));
				pnpdomain.setLn_purpose_others(rs.getString("LN_PURPOSE_OTHERS"));
				pnpdomain.setOccupation(rs.getString("OCCUPATION"));
				pnpdomain.setOccupation_na(rs.getString("OCCUPATION_NA"));
				pnpdomain.setOccupation_agri(rs.getString("OCCUPATION_AGRI"));
				pnpdomain.setOccupation_contract_emp(rs.getString("OCCUPATION_CONTRACT_EMP"));
				pnpdomain.setOccupation_self_emp(rs.getString("OCCUPATION_SELF_EMP"));
				pnpdomain.setOccupation_emp(rs.getString("OCCUPATION_EMP"));
				pnpdomain.setOccupation_others(rs.getString("OCCUPATION_OTHERS"));
				pnpdomain.setTotal_loan_dpd_current(rs.getString("TOTAL_LOAN_DPD_CURRENT"));
				pnpdomain.setTotal_loan_dpd_91_180(rs.getString("TOTAL_LOAN_DPD_91_180"));
				pnpdomain.setTotal_loan_dpd_grtr180(rs.getString("TOTAL_LOAN_DPD_GRTR180"));
				pnpdomain.setAmount_overdue(rs.getString("AMOUNT_OVERDUE"));
				pnpdomain.setAmount_overdue_dpd_0(rs.getString("AMOUNT_OVERDUE_DPD_0"));
				pnpdomain.setAmount_overdue_dpd_1_30(rs.getString("AMOUNT_OVERDUE_DPD_1_30"));
				pnpdomain.setAmount_overdue_dpd_31_60(rs.getString("AMOUNT_OVERDUE_DPD_31_60"));
				pnpdomain.setAmount_overdue_dpd_61_90(rs.getString("AMOUNT_OVERDUE_DPD_61_90"));
				pnpdomain.setAmount_overdue_dpd_91_180(rs.getString("AMOUNT_OVERDUE_DPD_91_180"));
				pnpdomain.setAmount_overdue_dpd_grtr180(rs.getString("AMOUNT_OVERDUE_DPD_GRTR180"));
				pnpdomain.setPortfolio_overdue_dpd_current(rs.getString("PORTFOLIO_OVERDUE_DPD_CURRENT"));
				pnpdomain.setPortfolio_overdue_dpd_91_180(rs.getString("PORTFOLIO_OVERDUE_DPD_91_180"));
				pnpdomain.setPortfolio_overdue_dpd_grtr180(rs.getString("PORTFOLIO_OVERDUE_DPD_GRTR180"));
				pnpdomain.setTotal_shg_ln(rs.getString("TOTAL_SHG_LN"));
				pnpdomain.setTotal_shg_overdue_ln(rs.getString("TOTAL_SHG_OVERDUE_LN"));
				pnpdomain.setShg_ln_overdue_amt(rs.getString("SHG_LN_OVERDUE_AMT"));
				pnpdataList.add(pnpdomain);
			}
			}
			//pstmt.close();
			System.out.println("Requested Pincode Retrived after paging Sucessfully");

			

			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw  new Exception("Error While Inserting Data");
		}
		finally{
			if(con!=null)
			con.close();
		}
		return pnpdataList;
		
	}

	public String exctractprice_(String reg_id, String regcustid,String prodId,String pincodes,boolean tpstsflag,boolean tpstartflag) throws Exception {
		
		String METHODNAME = "exctractprice_()";
		Connection con = null;
		
		String price=null;
		String pinrqst[]=null;
		int pnpcnt=0;
		int totvol=0;
		String flag=null;
		String prodprice = null;
		String fixPrice=null;
		int fixcnt=0;
		Date prddt=null;
		Date prdfrmdt=null;
		if(StringUtils.isNotBlank(pincodes))
			pinrqst=StringUtils.split(pincodes, "|");
		
		try{
			int trialpd = 0;
			Date tptodate = null;
			Date tpfromdt=null;
			String sysdate=null;
			String tpstatus=null;
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			SimpleDateFormat dateFormat1 = new SimpleDateFormat("dd-MMM-yy");
			Date date = new Date();
			Date sysdt=date;
			sysdate=dateFormat.format(sysdt);
			
			
			Date finalsysdate = dateFormat.parse(sysdate);
			con = getConnection();
			PreparedStatement pstmt = null;
				String Query="select TRIAL_PERIOD,TO_DATE(TO_DATE,'dd-mm-yyyy') as TO_DATE,TO_DATE(FROM_DATE,'dd-mm-yyyy') as FROM_DATE from Hm_Trial_Period_Tbl where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
				String QuerySts="select STATUS from Hm_Trial_Period_Tbl where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"'";
				pstmt=con.prepareStatement(QuerySts);
				ResultSet rs1 = pstmt.executeQuery();
				if(rs1.next())
				{
					tpstatus=rs1.getString("STATUS");
				}
				if(!tpstsflag)
				if(StringUtils.isBlank(tpstatus) || StringUtils.equalsIgnoreCase(tpstatus, "002"))
				{
					return "tpnotapprove";
				}
				
				pstmt=con.prepareStatement(Query);
				ResultSet rs = pstmt.executeQuery();
				
				if (rs.next()) {
					trialpd=rs.getInt("TRIAL_PERIOD");
					tptodate=rs.getDate("TO_DATE");
					tpfromdt=rs.getDate("FROM_DATE");
					//return price;
				}
				
				if(trialpd==1 && !finalsysdate.before(tpfromdt))
				{
					if((finalsysdate.after(tpfromdt)||finalsysdate.equals(tpfromdt)) && (finalsysdate.before(tptodate)||finalsysdate.equals(tptodate)))			//if trial period expired it gives msg. and update TRIAL_PERIOD=0 and price access from product access form
					{
						String Query1="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request Where REG_CUST_ID='"+regcustid+"' " +
								"and PINOCDE_RESPONSE=1 and PRICE=0 and trunc(Request_Date) between('"+dateFormat1.format(tpfromdt)+"') and ('"+dateFormat1.format(tptodate)+"')";
						pstmt=con.prepareStatement(Query1);
						ResultSet rsvol = pstmt.executeQuery();
						
						while (rsvol.next()) {
							pnpcnt=rsvol.getInt("CNT");
						}
						System.out.println("Total PNP Count aleready rqsted: "+pnpcnt);
						
						String Query2="Select VOLUME From hm_trial_period_tbl Where REG_CUST_ID='"+regcustid+"' and Product_id='"+prodId+"'";
						pstmt=con.prepareStatement(Query2);
						ResultSet rss = pstmt.executeQuery();
						
						while (rss.next()) {
							totvol=rss.getInt("VOLUME");
						}
						System.out.println("Total Volume in Trial Period: "+totvol);
						int finalcnt=totvol-pnpcnt;
						System.out.println("Total Final Cnt: "+finalcnt);
						if(totvol>=pnpcnt)
						{
							if(finalcnt>=pinrqst.length)
							price="0";
							else
							{
								
								 if(finalcnt<=pinrqst.length)
								{
									String Queryforflag="select TO_DATE(VALID_FROM,'dd-mm-yyyy') as VALID_FROM,FIXED_NUMBER_OF_REQUEST,FIXED_FLAG,PRICE,FIXED_PRICE,TO_DATE(VALID_UPTO,'dd-mm-yyyy') as VALID_UPTO from Hm_Product_Access where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
									pstmt=con.prepareStatement(Queryforflag);
									ResultSet rsss = pstmt.executeQuery();
									while (rsss.next()) {
										flag=rsss.getString("FIXED_FLAG");
										prodprice=rsss.getString("PRICE");
										fixPrice=rsss.getString("FIXED_PRICE");
										prddt=rsss.getDate("VALID_UPTO");
										prdfrmdt=rsss.getDate("VALID_FROM");
										fixcnt=rsss.getInt("FIXED_NUMBER_OF_REQUEST");
										
									}
									if(StringUtils.equalsIgnoreCase(flag, "0"))
									{
										price=prodprice;
									}
									else if(StringUtils.equalsIgnoreCase(flag, "1"))			//if fix price date expired it will take base price as price
									{
										if((finalsysdate.after(prdfrmdt) || finalsysdate.equals(prdfrmdt))&& (finalsysdate.before(prddt) || finalsysdate.equals(prddt)))
										{
										String Query3="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request " +
												"Where REG_CUST_ID='"+regcustid+"' and PINOCDE_RESPONSE=1 and " +
												"PRICE="+fixPrice+" and trunc(Request_Date) between('"+dateFormat1.format(prdfrmdt)+"') and ('"+dateFormat1.format(prddt)+"')";
										pstmt=con.prepareStatement(Query3);
										ResultSet rsfix = pstmt.executeQuery();
										
										while (rsfix.next()) {
											pnpcnt=rsfix.getInt("CNT");
										}
										int fixfinalcnt=fixcnt-pnpcnt;
										if(finalsysdate.after(prddt))
										{
											fixfinalcnt=0;
										}
										if((finalsysdate.before(prddt)||finalsysdate.equals(prddt))  && pnpcnt<fixcnt && fixfinalcnt>=pinrqst.length)
										price=fixPrice;
										else if(fixfinalcnt<pinrqst.length)
										{
											//fixfinalcnt=pinrqst.length-finalcnt;
											return "fixexp"+"|"+prodprice+"|"+fixPrice+"|"+fixfinalcnt+"|"+finalcnt;
										}
										}
										else
										{
											System.out.println("Fix Product Access on if Sydate is between Fix From and To Date.");
											price=prodprice;
										}
									}
									return "volexp"+"|"+finalcnt+"|"+price;
									
								}
							}
							
						}
						else
						{
							
							pstmt = con.prepareStatement("UPDATE HM_TRIAL_PERIOD_TBL SET TRIAL_PERIOD=0 WHERE REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS='' ");
							pstmt.executeUpdate();
							pstmt.close();
							
							String Queryforflag="select TO_DATE(VALID_FROM,'dd-mm-yyyy') as VALID_FROM,FIXED_NUMBER_OF_REQUEST,FIXED_FLAG,PRICE,FIXED_PRICE,TO_DATE(VALID_UPTO,'dd-mm-yyyy') as VALID_UPTO from Hm_Product_Access where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
							pstmt=con.prepareStatement(Queryforflag);
							ResultSet rsss = pstmt.executeQuery();
							while (rsss.next()) {
								flag=rsss.getString("FIXED_FLAG");
								prodprice=rsss.getString("PRICE");
								fixPrice=rsss.getString("FIXED_PRICE");
								prddt=rsss.getDate("VALID_UPTO");
								fixcnt=rsss.getInt("FIXED_NUMBER_OF_REQUEST");
								prdfrmdt=rsss.getDate("VALID_FROM");
							}
							if(StringUtils.equalsIgnoreCase(flag, "0"))
							{
								price=prodprice;
							}
							else if(StringUtils.equalsIgnoreCase(flag, "1"))			//if fix price date expired it will take base price as price
							{
								if((finalsysdate.after(prdfrmdt) || finalsysdate.equals(prdfrmdt))&& (finalsysdate.before(prddt) || finalsysdate.equals(prddt)))
								{
								String Query3="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request " +
										"Where REG_CUST_ID='"+regcustid+"' and PINOCDE_RESPONSE=1 and " +
												"PRICE="+fixPrice+" and trunc(Request_Date) between('"+dateFormat1.format(prdfrmdt)+"') and ('"+dateFormat1.format(prddt)+"')";
								pstmt=con.prepareStatement(Query3);
								ResultSet rsfix = pstmt.executeQuery();
								
								while (rsfix.next()) {
									pnpcnt=rsfix.getInt("CNT");
								}
								int fixfinalcnt=fixcnt-pnpcnt;
								if(finalsysdate.after(prddt))
								{
									fixfinalcnt=0;
								}
								if((finalsysdate.before(prddt)||finalsysdate.equals(prddt))  && pnpcnt<fixcnt && fixfinalcnt>=pinrqst.length)
									price=fixPrice;
									else if(fixfinalcnt<pinrqst.length)
										return "fixexp"+"|"+prodprice+"|"+fixPrice+"|"+fixfinalcnt+"|"+finalcnt;	
								}
								else
								{
									System.out.println("Fix Product Access on if Sydate is between Fix From and To Date.");
									price=prodprice;
								}
							}
							return "volexp "+"|"+finalcnt+"|"+price;
							//return "volexp "+"|"+finalcnt;
							
						}
					}
						
					else
					{
						pstmt = con.prepareStatement("UPDATE HM_TRIAL_PERIOD_TBL SET TRIAL_PERIOD=0 WHERE REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001");
					pstmt.executeUpdate();
					pstmt.close();	
					return "expired";
					}
					
					
					
				}
				else if(!tpstartflag && trialpd==1)
				{
					return "tpnotstart";
				}
				
					else if(trialpd==0 || rs==null || finalsysdate.before(tpfromdt))
					{
						/*String flag=null;
						String prodprice = null;
						String fixPrice=null;
						Date prddt=null;*/
						String Queryforflag="select TO_DATE(VALID_FROM,'dd-mm-yyyy') as VALID_FROM,FIXED_NUMBER_OF_REQUEST,FIXED_FLAG,PRICE,FIXED_PRICE,TO_DATE(VALID_UPTO,'dd-mm-yyyy') as VALID_UPTO from Hm_Product_Access where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
						pstmt=con.prepareStatement(Queryforflag);
						ResultSet rss = pstmt.executeQuery();
						while (rss.next()) {
							flag=rss.getString("FIXED_FLAG");
							prodprice=rss.getString("PRICE");
							fixPrice=rss.getString("FIXED_PRICE");
							prddt=rss.getDate("VALID_UPTO");
							fixcnt=rss.getInt("FIXED_NUMBER_OF_REQUEST");
							prdfrmdt=rss.getDate("VALID_FROM");
						}
						
						if(StringUtils.equalsIgnoreCase(flag, "0") )
						{
							price=prodprice;
						}
						else if(StringUtils.equalsIgnoreCase(flag, "1"))			//if fix price date expired it will take base price as price
						{
							if((finalsysdate.after(prdfrmdt) || finalsysdate.equals(prdfrmdt)) && (finalsysdate.before(prddt) || finalsysdate.equals(prddt)))
							{
							String Query3="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request " +
									"Where REG_CUST_ID='"+regcustid+"' and PINOCDE_RESPONSE=1 and " +
									"PRICE="+fixPrice+" and trunc(Request_Date) between('"+dateFormat1.format(prdfrmdt)+"') and ('"+dateFormat1.format(prddt)+"')";;
							pstmt=con.prepareStatement(Query3);
							ResultSet rsfix = pstmt.executeQuery();
							
							while (rsfix.next()) {
								pnpcnt=rsfix.getInt("CNT");
							}
							int fixfinalcnt=fixcnt-pnpcnt;
							if(finalsysdate.after(prddt))
							{
								fixfinalcnt=0;
							}
							if((finalsysdate.before(prddt)||finalsysdate.equals(prddt))  && pnpcnt<fixcnt && fixfinalcnt>=pinrqst.length)
								price=fixPrice;
								else if(fixfinalcnt<pinrqst.length)
									return "fixexp"+"|"+prodprice+"|"+fixPrice+"|"+fixfinalcnt;	
							}
							else
							{
								System.out.println("Fix Product Access on if Sydate is between Fix From and To Date.");
								price=prodprice;
							}
						}
					//}
				}
				
				
				
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw  new Exception("Error While Fetching Data");
		}
		finally{
			if(con!=null)
			con.close();
		}
		return price;
	}
	public List<PnpCountDomain> getpincodeDetails(String fromDt ,String toDt)throws Exception
	{
		final String METHODNAME = "getpincodeDetails()";
		
		DataSource dataSource ;
		JdbcTemplate jdbcTemplate= null;
		List<PnpCountDomain> detailList = null;
		String l_query = null;
		try
		{
			dataSource = ConnectionManager.getDataSource();   
			jdbcTemplate = new JdbcTemplate(dataSource);
		l_query="select r.EMP_NAME as empName,cu.CUSTOMER_ID as custId,cu.CUSTOMER_NAME as custName,DUMP_MONTH as dumpMonth,PRICE,pcount as pinCount FROM ( select REG_ID,REG_CUST_ID,DUMP_MONTH,PRICE,count(PINOCDE_RESPONSE) as pcount from HM_PINCODE_REQUEST " +
				" where to_date(REQUEST_DATE) BETWEEN TO_DATE('"+fromDt+"','DD-MM-YYYY') AND TO_DATE('"+toDt+"','DD-MM-YYYY') group by REG_ID,REG_CUST_ID,DUMP_MONTH,PRICE,PINOCDE_RESPONSE " +
				"having PINOCDE_RESPONSE='1' )a inner join HM_CUST_REGISTRATION cu ON a.REG_CUST_ID=cu.REG_CUST_ID inner join HM_USER_REGISTRATION r on a.REG_ID=r.REG_ID";
		detailList= jdbcTemplate.queryForList(l_query);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
			
		return detailList;
	}

	public Map<String, String> getProductList_(String institutename) throws PNPException {


		String METHODNAME = "getProductList_()";
		Map<String, String> productlist = new HashMap<String, String>();
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			String str[]=StringUtils.split(institutename,"|");
			
	String Query="select PRODUCT_NAME,PRODUCT_ID from hm_product_pnp " +
			"where PRODUCT_ID in(select PRODUCT_ID from Hm_Product_Access where REG_CUST_ID='"+str[0]+"')";
	     ProductAccessDomain proObj;
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				
				productlist.put(rs.getString("PRODUCT_ID"), rs.getString("PRODUCT_NAME"));

			}

		} catch (SQLException se) {
			if (error) {
				LOGGER.error("Exception" + se.getMessage());
			}
			se.printStackTrace();
			Trace trace = new Trace(this.getClass(), METHODNAME);
			throw new PNPException(trace,
					"Error while  retriving Product details List", se);
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					if (error) {
						LOGGER.error("Exception" + se.getMessage());
					}
					Trace trace = new Trace(this.getClass(), METHODNAME);
					throw new ConnectionNotFoundException(
							"Connection Not Found");
				}
			} else {
				if (debug) {
					LOGGER.debug("connection not open");
				}
			}
		}

		if (debug) {
			LOGGER.debug("Returning from " + METHODNAME + " in " + CLASSNAME);
		}
		return productlist;



}

	public List<PnpReportDomain> savepinrqstwithfixprice_(String reg_id,
			String institutename, String pincode, String price,String pid,
			String fixprice, String freecnt,String dist,String state, Connection con) throws Exception{
		
		String METHODNAME = "savepinrqstwithfixprice_()";
		//Connection con = getConnection();
		con.setAutoCommit(false);
		//Connection con = null;
		String pinrqst[]=null;
		String validpinrqst[]=null;
		String invalidpinrqst[]=null;
		int pnpcnt=0;
		int free=Integer.parseInt(freecnt);
		String validpin="";
		String invalidpin="";
		PreparedStatement pstUpdate = null;
		String pincodematch=null;
		String pinlist="";
		
		if(StringUtils.isBlank(state) && StringUtils.isBlank(dist))
		{
		if(StringUtils.isNotBlank(pincode))
		{
			DataSource dataSource = getDataSource();
			PincodeListProcedure sproc = new PincodeListProcedure(dataSource);
			Map<?, ?> l_parameterMap = sproc.setParameters(pincode,institutename);
			Map<?, ?> results = sproc.execute(l_parameterMap);
			if (null != results) {
				pincodematch =  (String) results.get(OUT_PARAM_1);
				pincode=(String)results.get(OUT_PARAM_2);
				}
		}
		}
		else
		{
			DataSource dataSource = getDataSource();
			PincodeListProcedureForStaeDist sproc = new PincodeListProcedureForStaeDist(dataSource);
			Map<?, ?> l_parameterMap = sproc.setParametersForStateDist(dist,state,institutename);
			Map<?, ?> results = sproc.execute(l_parameterMap);
			ResultSet rs1=null;
			ResultSet rs2=null;
			if (null != results) {
				String str="|";
				String str1="|";
				rs1 = ((ResultSetWrappingSqlRowSet) results
						.get(OUT_PARAM_1_AS_CURSOR)).getResultSet();
				rs2 = ((ResultSetWrappingSqlRowSet) results
						.get(OUT_PARAM_2_AS_CURSOR)).getResultSet();
				if(null !=rs1 )
				{
					while(rs1.next())
					{
						//custmerlist.put((rs.getString("REG_CUST_ID").trim()+"|"+rs.getString("CUSTOMER_NAME").trim()),rs.getString("CUSTOMER_NAME").trim());
						str=str+rs1.getString("PIN_CODE").trim();
											
					}
					pincodematch=str;
					pincodematch=StringUtils.removeStart(pincodematch,"|");
				}
				if(null !=rs2 )
				{
					while(rs2.next())
					{
						//custmerlist.put((rs.getString("REG_CUST_ID").trim()+"|"+rs.getString("CUSTOMER_NAME").trim()),rs.getString("CUSTOMER_NAME").trim());
						str1=str1+rs2.getString("PIN_CODE").trim();
											
					}
					pincode=str1;
					pincode=StringUtils.removeStart(pincode,"|");
				}
				}
		}
		//System.out.println("Pincodes Not in pinrqst tbl: "+pincode);
		//System.out.println("Pincodes in pinrqst tbl: "+pincodematch);
		if(StringUtils.isNotBlank(pincodematch) && StringUtils.isNotBlank(pincode))
			pinlist=pincodematch+pincode;
			else if(StringUtils.isBlank(pincodematch) && StringUtils.isNotBlank(pincode))
				pinlist=pincode;
			else
				pinlist=pincodematch;

		
		List<PnpReportDomain> pnpdataList =new ArrayList<PnpReportDomain>();
		int i = 0;
		try{
			//con = getConnection();
			PreparedStatement pstmt = null;
			if(StringUtils.isNotBlank(pincode))
			{	
				pinrqst=StringUtils.split(pincode, "|");
			
			int cnt=0;
			
			
			for(i=0;i<=pinrqst.length-1;i++)
			{
				PreparedStatement stmt = null;
				String Query="select * from hm_pin_pnp_test where PIN_CODE='"+pinrqst[i]+"'";
				stmt=con.prepareStatement(Query);
				ResultSet rs = stmt.executeQuery();
				
				while (rs.next()) {
					cnt++;
				}
				if(cnt>0)
				{
					validpin=validpin+","+pinrqst[i];
					cnt=0;
				}
				else if(cnt==0)
				{
					invalidpin=invalidpin+","+pinrqst[i];
				}
				rs.close();
				stmt.close();
			}
			validpin=StringUtils.removeStart(validpin, ",");
			invalidpin=StringUtils.removeStart(invalidpin, ",");
			validpinrqst=StringUtils.split(validpin, ",");
			invalidpinrqst=StringUtils.split(invalidpin, ",");
			Date dt=new Date();
			Calendar cal = Calendar.getInstance();
			String month=new SimpleDateFormat("MMM").format(cal.getTime());
			String yr=new SimpleDateFormat("yyyy").format(cal.getTime());
			String totvol=null;
			
			for(i=0;i<=validpinrqst.length-1;i++)
			{
			if(free!=0)
			{
			String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
					"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
			pstmt = con.prepareStatement(sqlLog);

			pstmt.setInt(1, Integer.parseInt(reg_id));
			pstmt.setString(2,institutename);
			pstmt.setString(3,validpinrqst[i]);
			pstmt.setInt(4,1);	
			
			pstmt.setString(5,fixprice);
			pstmt.setString(6,month+"-"+yr);
			
			pstmt.executeUpdate();
			pstmt.close();
			free--;
			if(free==0)
			{
				pstmt = con.prepareStatement("UPDATE Hm_Product_Access SET FIXED_FLAG=0 WHERE REG_CUST_ID='"+institutename+"' and PRODUCT_ID='"+pid+"'");
				pstmt.executeUpdate();
				pstmt.close();	
			}
			}
			else
			{
				
			String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
			"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
	pstmt = con.prepareStatement(sqlLog);

	pstmt.setInt(1, Integer.parseInt(reg_id));
	pstmt.setString(2,institutename);
	pstmt.setString(3,validpinrqst[i]);
	pstmt.setInt(4,1);	
	
	pstmt.setString(5,price);
	pstmt.setString(6,month+"-"+yr);
	
	pstmt.executeUpdate();
	pstmt.close();
			}
			}
			for(i=0;i<=invalidpinrqst.length-1;i++)
			{
			
			String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
					"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
			pstmt = con.prepareStatement(sqlLog);

			pstmt.setInt(1, Integer.parseInt(reg_id));
			pstmt.setString(2,institutename);
			pstmt.setString(3,invalidpinrqst[i]);
			pstmt.setInt(4,0);			
			pstmt.setString(5,price);
			pstmt.setString(6,month+"-"+yr);
			
			pstmt.executeUpdate();
			pstmt.close();
			}
			

			}
			ResultSet rs =null;
			if(StringUtils.isNotBlank(pinlist) && StringUtils.isBlank(state) && StringUtils.isBlank(dist))
			{
				//SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
				pinlist=pinlist.replace("|", ",");
				pinlist=StringUtils.removeEnd(pinlist, ",");			
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where Pin_code in("+pinlist+") and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			rs = object.getResultSet();
			}
			else if(StringUtils.isNotBlank(state) && StringUtils.isNotBlank(dist) && !StringUtils.equalsIgnoreCase(state, "S"))
			{
				
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where district in("+dist+") and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			rs = object.getResultSet();
			}
			else if(StringUtils.isNotBlank(state) && StringUtils.isNotBlank(dist) && StringUtils.equalsIgnoreCase(state, "S"))
			{
				
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where state_code in('"+dist+"') and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			rs = object.getResultSet();
			}
			while(rs.next())
			{
				//Date dt=formatter.parse(rs.getString("OLDEST_LOAN"));
				PnpReportDomain pnpdomain = new PnpReportDomain();
				pnpdomain.setDistrict(rs.getString("DISTRICT"));
				pnpdomain.setPincode(rs.getString("PIN_CODE"));
				pnpdomain.setStatecode(rs.getString("STATE_CODE"));
				pnpdomain.setTotalmfis(rs.getString("TOTAL_MFIS"));
				pnpdomain.setTotal_act_mfi(rs.getString("TOTAL_ACTIV_MFI"));
				pnpdomain.setTot_center(rs.getString("TOTAL_CENTERS"));
				pnpdomain.setTot_borowers(rs.getString("TOTAL_BORROWERS"));
				pnpdomain.setTot_act_borowers(rs.getString("TOTAL_ACTIV_BORROWERS"));
				pnpdomain.setTot_overdue_borrowers(rs.getString("TOTAL_OVERDUE_BORROWERS"));
				pnpdomain.setTot_active_loans(rs.getString("TOTAL_ACTIV_LOANS"));
				pnpdomain.setTot_active_dis_amnt(rs.getString("TOTAL_ACTIV_DISBURSED_AMOUNT"));
				pnpdomain.setTot_active_out_amnt(rs.getString("TOTAL_ACTIV_OUTSTANDING_AMOUNT"));
				pnpdomain.setTot_overdue_amnt(rs.getString("TOTAL_OVERDUE_AMOUNT"));
				pnpdomain.setAvg_loan(rs.getString("AVG_LOAN"));
				pnpdomain.setTotal_closed_loan(rs.getString("TOTAL_CLOSED_LOANS"));
				pnpdomain.setOldest_loan(rs.getString("OLDEST_LOAN"));
				pnpdomain.setTotal_loan_overdue(rs.getString("TOTAL_LOANS_OVERDUE"));
				pnpdomain.setTotal_loan_dpd_0(rs.getString("TOTAL_LOAN_DPD_0"));
				pnpdomain.setTotal_loan_dpd_1_30(rs.getString("TOTAL_LOAN_DPD_1_30"));
				pnpdomain.setTotal_loan_dpd_31_60(rs.getString("TOTAL_LOAN_DPD_31_60"));
				pnpdomain.setTotal_loan_dpd_61_90(rs.getString("TOTAL_LOAN_DPD_61_90"));
				pnpdomain.setPortfolio_overdue(rs.getString("PORTFOLIO_OVERDUE"));
				pnpdomain.setPortfolio_overdue_dpd_0(rs.getString("PORTFOLIO_OVERDUE_DPD_0"));
				pnpdomain.setPortfolio_overdue_dpd_1_30(rs.getString("PORTFOLIO_OVERDUE_DPD_1_30"));
				pnpdomain.setPortfolio_overdue_dpd_31_60(rs.getString("PORTFOLIO_OVERDUE_DPD_31_60"));
				pnpdomain.setPortfolio_overdue_dpd_61_90(rs.getString("PORTFOLIO_OVERDUE_DPD_61_90"));
				pnpdomain.setTot_write_off_loan(rs.getString("TOTAL_WRITE_OFF_LOANS"));
				pnpdomain.setTot_write_off_amnt(rs.getString("TOTAL_WRITE_OFF_AMT"));
				pnpdomain.setBorrow_in_ln_cycle_1(rs.getString("BORRWER_IN_LN_CYCLE_1"));
				pnpdomain.setBorrow_in_ln_cycle_2(rs.getString("BORRWER_IN_LN_CYCLE_2"));
				pnpdomain.setBorrow_in_ln_cycle_3_grtr(rs.getString("BORRWER_IN_LN_CYCLE_3_GRTR"));
				pnpdomain.setTot_ind_ln(rs.getString("TOTAL_IND_LN"));
				pnpdomain.setTot_ind_overdue_ln(rs.getString("TOTAL_IND_OVERDUE_LN"));
				pnpdomain.setInd_ln_overdue_amnt(rs.getString("IND_LN_OVERDUE_AMT"));
				pnpdomain.setTot_grp_ln(rs.getString("TOTAL_GROUP_LN"));
				pnpdomain.setTot_grp_overdue_ln(rs.getString("TOTAL_GROUP_OVERDUE_LN"));
				pnpdomain.setGrp_ln_overdue_amnt(rs.getString("GROUP_LN_OVERDUE_AMT"));
				pnpdomain.setBorrowers(rs.getString("BORROWERS"));
				pnpdomain.setBorrowers_na(rs.getString("BORROWER_NA"));
				pnpdomain.setBorrowers_0_5k(rs.getString("BORROWER_0_5K"));
				pnpdomain.setBorrowers_5k_10k(rs.getString("BORROWER_5K_10K"));
				pnpdomain.setBorrowers_10k_15k(rs.getString("BORROWER_10K_15K"));
				pnpdomain.setBorrowers_15k_50k(rs.getString("BORROWER_15K_50K"));
				pnpdomain.setBorrowers_50k_1lac(rs.getString("BORROWER_50K_1LACS"));
				pnpdomain.setBorrowers_grt_1lac(rs.getString("BORROWER_GRTR_1LACS"));
				pnpdomain.setInstlmnt_amnt(rs.getString("INSTALLMENT_AMT"));
				pnpdomain.setInstlmnt_0_6_0_15k(rs.getString("INSTALL_0_6_0_15K"));
				pnpdomain.setInstlmnt_0_6_15k_35k(rs.getString("INSTALL_0_6_15K_35K"));
				pnpdomain.setInstlmnt_0_6_35k_50k(rs.getString("INSTALL_0_6_35K_50K"));
				pnpdomain.setInstlmnt_0_6_grt_50k(rs.getString("INSTALL_0_6_GRTR_50K"));
				pnpdomain.setInstlmnt_7_12_0_15k(rs.getString("INSTALL_7_12_0_15K"));
				pnpdomain.setInstlmnt_7_12_15k_35k(rs.getString("INSTALL_7_12_15K_35K"));
				pnpdomain.setInstlmnt_7_12_35k_50k(rs.getString("INSTALL_7_12_35K_50K"));
				pnpdomain.setInstlmnt_7_12_grt_50k(rs.getString("INSTALL_7_12_GRTR_50K"));
				pnpdomain.setInstlmnt_13_24_0_15k(rs.getString("INSTALL_13_24_0_15K"));
				pnpdomain.setInstlmnt_13_24_15k_35k(rs.getString("INSTALL_13_24_15K_35K"));
				pnpdomain.setInstlmnt_13_24_35k_50k(rs.getString("INSTALL_13_24_35K_50K"));
				pnpdomain.setInstlmnt_13_24_grt_50k(rs.getString("INSTALL_13_24_GRTR_50K"));
				pnpdomain.setInstlmnt_grtr24_0_15k(rs.getString("INSTALL_GRTR24_0_15K"));
				pnpdomain.setInstlmnt_grtr24_15k_35k(rs.getString("INSTALL_GRTR24_15K_35K"));
				pnpdomain.setInstlmnt_grtr24_35k_50k(rs.getString("INSTALL_GRTR24_35K_50K"));
				pnpdomain.setInstlmnt_grtr24_grtr_50k(rs.getString("INSTALL_GRTR24_GRTR_50K"));
				pnpdomain.setLn_cycle(rs.getString("LN_CYCLE"));
				pnpdomain.setLn_1_0_15k(rs.getString("LN_1_0_15K"));
				pnpdomain.setLn_1_15k_35k(rs.getString("LN_1_15K_35K"));
				pnpdomain.setLn_1_35k_50k(rs.getString("LN_1_35K_50K"));
				pnpdomain.setLn_1_grtr_50k(rs.getString("LN_1_GRTR_50K"));
				pnpdomain.setLn_2_0_15k(rs.getString("LN_2_0_15K"));
				pnpdomain.setLn_2_15k_35k(rs.getString("LN_2_15K_35K"));
				pnpdomain.setLn_2_35k_50k(rs.getString("LN_2_35K_50K"));
				pnpdomain.setLn_2_grtr_50k(rs.getString("LN_2_GRTR_50K"));
				pnpdomain.setLn_gtrt3_0_15k(rs.getString("LN_GRTR3_0_15K"));
				pnpdomain.setLn_grtr3_15k_35k(rs.getString("LN_GRTR3_15K_35K"));
				pnpdomain.setLn_grtr3_35k_50k(rs.getString("LN_GRTR3_35K_50K"));
				pnpdomain.setLn_grtr3_grtr_50k(rs.getString("LN_GRTR3_GRTR_50K"));
				pnpdomain.setOverlap(rs.getString("OVERLAP"));
				pnpdomain.setOut_of_complince(rs.getString("OUT_OF_COMPLIANCE"));
				pnpdomain.setmFI2(rs.getString("MFI2"));
				pnpdomain.setmFI3(rs.getString("MFI3"));
				pnpdomain.setmFI4(rs.getString("MFI4"));
				pnpdomain.setNo_of_defualts(rs.getString("NO_OF_DEFAULTS"));
				pnpdomain.setMfi_grt_4(rs.getString("MFI_GRTR_4"));
				pnpdomain.setLn_grt_50k(rs.getString("LN_GRTR_50K"));
				pnpdomain.setLoan_purpose(rs.getString("LOAN_PURPOSE"));
				pnpdomain.setLn_purpose_na(rs.getString("LN_PURPOSE_NA"));
				pnpdomain.setLn_purpose_income(rs.getString("LN_PURPOSE_INCOME"));
				pnpdomain.setLn_purpose_edu(rs.getString("LN_PURPOSE_EDU"));
				pnpdomain.setLn_purpose_house(rs.getString("LN_PURPOSE_HOUSE"));
				pnpdomain.setLn_purpose_auto(rs.getString("LN_PURPOSE_AUTOMOBILE"));
				pnpdomain.setLn_purpose_realestate(rs.getString("LN_PURPOSE_REALESTATE"));
				pnpdomain.setLn_purpose_others(rs.getString("LN_PURPOSE_OTHERS"));
				pnpdomain.setOccupation(rs.getString("OCCUPATION"));
				pnpdomain.setOccupation_na(rs.getString("OCCUPATION_NA"));
				pnpdomain.setOccupation_agri(rs.getString("OCCUPATION_AGRI"));
				pnpdomain.setOccupation_contract_emp(rs.getString("OCCUPATION_CONTRACT_EMP"));
				pnpdomain.setOccupation_self_emp(rs.getString("OCCUPATION_SELF_EMP"));
				pnpdomain.setOccupation_emp(rs.getString("OCCUPATION_EMP"));
				pnpdomain.setOccupation_others(rs.getString("OCCUPATION_OTHERS"));
				pnpdomain.setTotal_loan_dpd_current(rs.getString("TOTAL_LOAN_DPD_CURRENT"));
				pnpdomain.setTotal_loan_dpd_91_180(rs.getString("TOTAL_LOAN_DPD_91_180"));
				pnpdomain.setTotal_loan_dpd_grtr180(rs.getString("TOTAL_LOAN_DPD_GRTR180"));
				pnpdomain.setAmount_overdue(rs.getString("AMOUNT_OVERDUE"));
				pnpdomain.setAmount_overdue_dpd_0(rs.getString("AMOUNT_OVERDUE_DPD_0"));
				pnpdomain.setAmount_overdue_dpd_1_30(rs.getString("AMOUNT_OVERDUE_DPD_1_30"));
				pnpdomain.setAmount_overdue_dpd_31_60(rs.getString("AMOUNT_OVERDUE_DPD_31_60"));
				pnpdomain.setAmount_overdue_dpd_61_90(rs.getString("AMOUNT_OVERDUE_DPD_61_90"));
				pnpdomain.setAmount_overdue_dpd_91_180(rs.getString("AMOUNT_OVERDUE_DPD_91_180"));
				pnpdomain.setAmount_overdue_dpd_grtr180(rs.getString("AMOUNT_OVERDUE_DPD_GRTR180"));
				pnpdomain.setPortfolio_overdue_dpd_current(rs.getString("PORTFOLIO_OVERDUE_DPD_CURRENT"));
				pnpdomain.setPortfolio_overdue_dpd_91_180(rs.getString("PORTFOLIO_OVERDUE_DPD_91_180"));
				pnpdomain.setPortfolio_overdue_dpd_grtr180(rs.getString("PORTFOLIO_OVERDUE_DPD_GRTR180"));
				pnpdomain.setTotal_shg_ln(rs.getString("TOTAL_SHG_LN"));
				pnpdomain.setTotal_shg_overdue_ln(rs.getString("TOTAL_SHG_OVERDUE_LN"));
				pnpdomain.setShg_ln_overdue_amt(rs.getString("SHG_LN_OVERDUE_AMT"));
				pnpdataList.add(pnpdomain);
			}
			
			if(pstmt!=null)
			pstmt.close();
			System.out.println("Requested Pincode Saved Sucessfully");
			//con.commit();
			

			
		}
		catch (SQLException se)
	    {
		      se.printStackTrace();
		      con.rollback();
		      if (1 == se.getErrorCode()) {
		    	  Trace trace = new Trace(getClass(), METHODNAME);
				throw new UniqueKeyConstraintViolationException(
		          trace, 
		          "Already Registered Pincode:",validpinrqst[i]);
		      }
		      LOGGER.error("Exception" + se.getMessage());
		      Trace trace = new Trace(getClass(), METHODNAME);
		      throw new PNPException(trace, 
		        "Error while register pincode rqst information", 
		        se);
		    }
		catch (Exception e) {
			e.printStackTrace();
			con.rollback();
			throw  new Exception("Error While Inserting Data");
		}
		/*finally{
			if(con!=null)
			con.close();
		}*/
		return pnpdataList;
		
	}
	private class PincodeListProcedure extends StoredProcedure {

		private static final String PROC_NAME = "HMCORE.PR_PINCODES_LIST"; // Store
																								// name

		private final static String IN_PARAM_1 = "pv_in"; // IN
		private final static String IN_PARAM_2 ="pn_cid";  //IN
		private final static String OUT_PARAM_1="pv_pin_match";    //OUT
		private final static String OUT_PARAM_2="pv_pin_notmatch";  //OUT
		

		public PincodeListProcedure(DataSource ds) {
			setDataSource(ds);
			setSql(PROC_NAME);

			declareParameter(new SqlParameter(IN_PARAM_1, Types.VARCHAR));
			declareParameter(new SqlParameter(IN_PARAM_2, Types.NUMERIC));
			declareParameter(new SqlOutParameter(OUT_PARAM_1, Types.VARCHAR));
			declareParameter(new SqlOutParameter(OUT_PARAM_2, Types.VARCHAR));
			//declareParameter(new SqlOutParameter(OUT_PARAM_1_AS_CURSOR,OracleTypes.CURSOR, new SqlRowSetResultSetExtractor()));
			

			compile();
		}

		public Map<?, ?> setParameters(String inParam1,String inParam2) {
			HashMap<String, Object> inParams = new HashMap<String, Object>();
			if ("".equals(StringUtils.isBlank(inParam1))) {
				inParams.put(IN_PARAM_1, "");
			} else {
				inParams.put(IN_PARAM_1, inParam1);
			}
			if ("".equals(StringUtils.isBlank(inParam2))) {
				inParams.put(IN_PARAM_2, "");
			} else {
				inParams.put(IN_PARAM_2, Integer.parseInt(inParam2));
			}
			
			return inParams;
		}
	}
	private class PincodeListProcedureForStaeDist extends StoredProcedure {

		private static final String PROC_NAME = "PK_PNP_COUNT_CALL.PR_PINCODES_LIST"; // Store
																								// name

		private final static String IN_PARAM_1 = "pv_state_district_name"; // IN
		private final static String IN_PARAM_2 ="pv_flag";  //IN
		private final static String IN_PARAM_3 ="pn_cid";
		
		private final static String OUT_PARAM_1="CUR_MATCH";    //OUT
		private final static String OUT_PARAM_2="CUR_UNMATCH";  //OUT
		

		public PincodeListProcedureForStaeDist(DataSource ds) {
			setDataSource(ds);
			setSql(PROC_NAME);

			declareParameter(new SqlParameter(IN_PARAM_1, Types.VARCHAR));
			declareParameter(new SqlParameter(IN_PARAM_2, Types.VARCHAR));
			declareParameter(new SqlParameter(IN_PARAM_3, Types.NUMERIC));
			
			//declareParameter(new SqlOutParameter(OUT_PARAM_1, Types.VARCHAR));
			//declareParameter(new SqlOutParameter(OUT_PARAM_2, Types.VARCHAR));
			declareParameter(new SqlOutParameter(OUT_PARAM_1,OracleTypes.CURSOR, new SqlRowSetResultSetExtractor()));
			declareParameter(new SqlOutParameter(OUT_PARAM_2,OracleTypes.CURSOR, new SqlRowSetResultSetExtractor()));

			compile();
		}

		public Map<?, ?> setParametersForStateDist(String inParam1,String inParam2,String inParam3) {
			HashMap<String, Object> inParams = new HashMap<String, Object>();
			if ("".equals(StringUtils.isBlank(inParam1))) {
				inParams.put(IN_PARAM_1, "");
			} else {
				inParams.put(IN_PARAM_1, inParam1);
			}
			if ("".equals(StringUtils.isBlank(inParam2))) {
				inParams.put(IN_PARAM_2, "");
			} else {
				inParams.put(IN_PARAM_2,inParam2);
			}
			if ("".equals(StringUtils.isBlank(inParam3))) {
				inParams.put(IN_PARAM_3, "");
			} else {
				inParams.put(IN_PARAM_3, Integer.parseInt(inParam3));
			}
			
			return inParams;
		}
	}
	public List<PnpReportDomain> savepinrqstwithfixpriceandtp_(String reg_id,
			String institutename, String pincode, String price, String prodId,
			String fixprice, String freecnt, String freetpcnt,String dist,String state, Connection con) throws Exception{
		
		String METHODNAME = "savepinrqstwithfixpriceandtp_()";
		//Connection con = getConnection();
		con.setAutoCommit(false);
		//Connection con = null;
		String pinrqst[]=null;
		String validpinrqst[]=null;
		String invalidpinrqst[]=null;
		int pnpcnt=0;
		int free=Integer.parseInt(freecnt);
		int freetp=Integer.parseInt(freetpcnt);
		String validpin="";
		String invalidpin="";
		PreparedStatement pstUpdate = null;
		String pincodematch=null;
		String pinlist="";
		if(StringUtils.isBlank(state) && StringUtils.isBlank(dist))
		{
		if(StringUtils.isNotBlank(pincode))
		{
			DataSource dataSource = getDataSource();
			PincodeListProcedure sproc = new PincodeListProcedure(dataSource);
			Map<?, ?> l_parameterMap = sproc.setParameters(pincode,institutename);
			Map<?, ?> results = sproc.execute(l_parameterMap);
			if (null != results) {
				pincodematch =  (String) results.get(OUT_PARAM_1);
				pincode=(String)results.get(OUT_PARAM_2);
				}
		}
		}
		else
		{
			DataSource dataSource = getDataSource();
			PincodeListProcedureForStaeDist sproc = new PincodeListProcedureForStaeDist(dataSource);
			Map<?, ?> l_parameterMap = sproc.setParametersForStateDist(dist,state,institutename);
			Map<?, ?> results = sproc.execute(l_parameterMap);
			ResultSet rs1=null;
			ResultSet rs2=null;
			if (null != results) {
				String str="|";
				String str1="|";
				rs1 = ((ResultSetWrappingSqlRowSet) results
						.get(OUT_PARAM_1_AS_CURSOR)).getResultSet();
				rs2 = ((ResultSetWrappingSqlRowSet) results
						.get(OUT_PARAM_2_AS_CURSOR)).getResultSet();
				if(null !=rs1 )
				{
					while(rs1.next())
					{
						//custmerlist.put((rs.getString("REG_CUST_ID").trim()+"|"+rs.getString("CUSTOMER_NAME").trim()),rs.getString("CUSTOMER_NAME").trim());
						str=str+rs1.getString("PIN_CODE").trim();
											
					}
					pincodematch=str;
					pincodematch=StringUtils.removeStart(pincodematch, "|");
				}
				if(null !=rs2 )
				{
					while(rs2.next())
					{
						//custmerlist.put((rs.getString("REG_CUST_ID").trim()+"|"+rs.getString("CUSTOMER_NAME").trim()),rs.getString("CUSTOMER_NAME").trim());
						str1=str1+rs2.getString("PIN_CODE").trim();
											
					}
					pincode=str1;
					pincode=StringUtils.removeStart(pincode, "|");
					
				}
				}
		}
		//System.out.println("Pincodes Not in pinrqst tbl: "+pincode);
		//System.out.println("Pincodes in pinrqst tbl: "+pincodematch);
		if(StringUtils.isNotBlank(pincodematch) && StringUtils.isNotBlank(pincode))
			pinlist=pincodematch+pincode;
			else if(StringUtils.isBlank(pincodematch) && StringUtils.isNotBlank(pincode))
				pinlist=pincode;
			else
				pinlist=pincodematch;

		
		List<PnpReportDomain> pnpdataList =new ArrayList<PnpReportDomain>();
		int i = 0;
		try{
			//con = getConnection();
			PreparedStatement pstmt = null;
			if(StringUtils.isNotBlank(pincode))
			{	
				pinrqst=StringUtils.split(pincode, "|");
			
			int cnt=0;
			
			/*String Queryforflag="select FIXED_NUMBER_OF_REQUEST from Hm_Product_Access where REG_CUST_ID='"+institutename+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
			pstmt=con.prepareStatement(Queryforflag);
			ResultSet rsss = pstmt.executeQuery();
			int fixcnt=0;
			while (rsss.next()) {
				fixcnt=rsss.getInt("FIXED_NUMBER_OF_REQUEST");
				
			}*/
			for(i=0;i<=pinrqst.length-1;i++)
			{
				PreparedStatement stmt = null;
				String Query="select * from hm_pin_pnp_test where PIN_CODE='"+pinrqst[i]+"'";
				stmt=con.prepareStatement(Query);
				ResultSet rs = stmt.executeQuery();
				
				while (rs.next()) {
					cnt++;
				}
				if(cnt>0)
				{
					validpin=validpin+","+pinrqst[i];
					cnt=0;
				}
				else if(cnt==0)
				{
					invalidpin=invalidpin+","+pinrqst[i];
				}
				rs.close();
				stmt.close();
				
			}
			validpin=StringUtils.removeStart(validpin, ",");
			invalidpin=StringUtils.removeStart(invalidpin, ",");
			validpinrqst=StringUtils.split(validpin, ",");
			invalidpinrqst=StringUtils.split(invalidpin, ",");
			Date dt=new Date();
			Calendar cal = Calendar.getInstance();
			String month=new SimpleDateFormat("MMM").format(cal.getTime());
			String yr=new SimpleDateFormat("yyyy").format(cal.getTime());
			String totvol=null;
			
			for(i=0;i<=validpinrqst.length-1;i++)
			{
			if(free!=0)
			{
			String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
					"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
			pstmt = con.prepareStatement(sqlLog);

			pstmt.setInt(1, Integer.parseInt(reg_id));
			pstmt.setString(2,institutename);
			pstmt.setString(3,validpinrqst[i]);
			pstmt.setInt(4,1);	
			
			pstmt.setString(5,fixprice);
			pstmt.setString(6,month+"-"+yr);
			
			pstmt.executeUpdate();
			pstmt.close();
			//int f=fixcnt-free;

			free--;
			/*if(f==0)
			{
				pstmt = con.prepareStatement("UPDATE Hm_Product_Access SET FIXED_FLAG=0 WHERE REG_CUST_ID='"+institutename+"' and PRODUCT_ID='"+prodId+"'");
				pstmt.executeUpdate();
				pstmt.close();	
			}*/
			}
			else
			{
				if(freetp!=0)
				{
			String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
			"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
	pstmt = con.prepareStatement(sqlLog);

	pstmt.setInt(1, Integer.parseInt(reg_id));
	pstmt.setString(2,institutename);
	pstmt.setString(3,validpinrqst[i]);
	pstmt.setInt(4,1);	
	
	pstmt.setString(5,"0");
	pstmt.setString(6,month+"-"+yr);
	
	pstmt.executeUpdate();
	pstmt.close();
	freetp--;
	
	if(freetp==0)
	{
		pstmt = con.prepareStatement("UPDATE HM_TRIAL_PERIOD_TBL SET TRIAL_PERIOD=0 WHERE REG_CUST_ID='"+institutename+"' and PRODUCT_ID='"+prodId+"'");
		pstmt.executeUpdate();
		pstmt.close();	
	}
				}
				else
				{
					String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
					"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
			pstmt = con.prepareStatement(sqlLog);

			pstmt.setInt(1, Integer.parseInt(reg_id));
			pstmt.setString(2,institutename);
			pstmt.setString(3,validpinrqst[i]);
			pstmt.setInt(4,1);	
			
			pstmt.setString(5,price);
			pstmt.setString(6,month+"-"+yr);
			
			pstmt.executeUpdate();
			pstmt.close();
				}
				}
			}
			for(i=0;i<=invalidpinrqst.length-1;i++)
			{
			
			String sqlLog = "insert into HM_PINCODE_REQUEST(P_ID,REG_ID,Reg_Cust_Id,Pinocde_Request,Pinocde_Response,Request_Date,Price,DUMP_MONTH) " +
					"values(P_ID_SEQ.nextval,?,?,?,?,SYSDATE,?,?)";
			pstmt = con.prepareStatement(sqlLog);

			pstmt.setInt(1, Integer.parseInt(reg_id));
			pstmt.setString(2,institutename);
			pstmt.setString(3,invalidpinrqst[i]);
			pstmt.setInt(4,0);			
			pstmt.setString(5,price);
			pstmt.setString(6,month+"-"+yr);
			
			pstmt.executeUpdate();
			pstmt.close();
			}
			

			}
			ResultSet rs =null;
			if(StringUtils.isNotBlank(pinlist) && StringUtils.isBlank(state) && StringUtils.isBlank(dist))
			{
				//SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
				pinlist=pinlist.replace("|", ",");
				pinlist=StringUtils.removeEnd(pinlist, ",");			
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where Pin_code in("+pinlist+") and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			rs = object.getResultSet();
			}
			else if(StringUtils.isNotBlank(state) && StringUtils.isNotBlank(dist) && !StringUtils.equalsIgnoreCase(state, "S"))
			{
				
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where district in("+dist+") and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			rs = object.getResultSet();
			}
			else if(StringUtils.isNotBlank(state) && StringUtils.isNotBlank(dist) && StringUtils.equalsIgnoreCase(state, "S"))
			{
				
			DataSource ds=getDataSource();
			ResultSetWrappingSqlRowSet object;
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			String Query2="select DISTRICT,PIN_CODE,STATE_CODE,TOTAL_MFIS,TOTAL_ACTIV_MFI,TOTAL_CENTERS,TOTAL_BORROWERS,TOTAL_ACTIV_BORROWERS,TOTAL_OVERDUE_BORROWERS," +
					"TOTAL_ACTIV_LOANS,TOTAL_ACTIV_DISBURSED_AMOUNT,TOTAL_ACTIV_OUTSTANDING_AMOUNT,TOTAL_OVERDUE_AMOUNT,AVG_LOAN,TOTAL_CLOSED_LOANS," +
					"TO_CHAR(OLDEST_LOAN,'DD-MON-YY') OLDEST_LOAN,TOTAL_LOANS_OVERDUE,TOTAL_LOAN_DPD_0,TOTAL_LOAN_DPD_1_30,TOTAL_LOAN_DPD_31_60,TOTAL_LOAN_DPD_61_90," +
					"PORTFOLIO_OVERDUE,PORTFOLIO_OVERDUE_DPD_0,PORTFOLIO_OVERDUE_DPD_1_30,PORTFOLIO_OVERDUE_DPD_31_60," +
					"PORTFOLIO_OVERDUE_DPD_61_90,TOTAL_WRITE_OFF_LOANS,TOTAL_WRITE_OFF_AMT," +
					"BORRWER_IN_LN_CYCLE_1,BORRWER_IN_LN_CYCLE_2,BORRWER_IN_LN_CYCLE_3_GRTR,TOTAL_IND_LN,TOTAL_IND_OVERDUE_LN,IND_LN_OVERDUE_AMT," +
					"TOTAL_GROUP_LN,TOTAL_GROUP_OVERDUE_LN,GROUP_LN_OVERDUE_AMT,BORROWERS,BORROWER_NA,BORROWER_0_5K,BORROWER_5K_10K,BORROWER_10K_15K," +
					"BORROWER_15K_50K,BORROWER_50K_1LACS,BORROWER_GRTR_1LACS,INSTALLMENT_AMT,INSTALL_0_6_0_15K,INSTALL_0_6_15K_35K,INSTALL_0_6_35K_50K," +
					"INSTALL_0_6_GRTR_50K,INSTALL_7_12_0_15K,INSTALL_7_12_15K_35K,INSTALL_7_12_35K_50K,INSTALL_7_12_GRTR_50K,INSTALL_13_24_0_15K," +
					"INSTALL_13_24_15K_35K,INSTALL_13_24_35K_50K,INSTALL_13_24_GRTR_50K,INSTALL_GRTR24_0_15K,INSTALL_GRTR24_15K_35K,INSTALL_GRTR24_35K_50K," +
					"INSTALL_GRTR24_GRTR_50K,LN_CYCLE,LN_1_0_15K,LN_1_15K_35K,LN_1_35K_50K,LN_1_GRTR_50K,LN_2_0_15K,LN_2_15K_35K,LN_2_35K_50K," +
					"LN_2_GRTR_50K,LN_GRTR3_0_15K,LN_GRTR3_15K_35K,LN_GRTR3_35K_50K,LN_GRTR3_GRTR_50K,OVERLAP,OUT_OF_COMPLIANCE,MFI2,MFI3,MFI4,NO_OF_DEFAULTS," +
					"MFI_GRTR_4,LN_GRTR_50K,LOAN_PURPOSE,LN_PURPOSE_NA,LN_PURPOSE_INCOME,LN_PURPOSE_EDU,LN_PURPOSE_HOUSE,LN_PURPOSE_AUTOMOBILE," +
					"LN_PURPOSE_REALESTATE,LN_PURPOSE_OTHERS,OCCUPATION,OCCUPATION_NA,OCCUPATION_AGRI,OCCUPATION_CONTRACT_EMP,OCCUPATION_SELF_EMP,OCCUPATION_EMP," +
					"OCCUPATION_OTHERS,TOTAL_LOAN_DPD_CURRENT,TOTAL_LOAN_DPD_91_180,TOTAL_LOAN_DPD_GRTR180,AMOUNT_OVERDUE,AMOUNT_OVERDUE_DPD_0,AMOUNT_OVERDUE_DPD_1_30,"
					+ "AMOUNT_OVERDUE_DPD_31_60,AMOUNT_OVERDUE_DPD_61_90,AMOUNT_OVERDUE_DPD_91_180,AMOUNT_OVERDUE_DPD_GRTR180,PORTFOLIO_OVERDUE_DPD_CURRENT,"
					+ "PORTFOLIO_OVERDUE_DPD_91_180,PORTFOLIO_OVERDUE_DPD_GRTR180,TOTAL_SHG_LN,TOTAL_SHG_OVERDUE_LN,SHG_LN_OVERDUE_AMT from hm_pin_pnp_test where state_code in('"+dist+"') and combo like '%PIN|OVERALL|PERCENTAGE|PNP%' ";
			
			//pnpdataList =jdbcTemplate.queryForList(Query1);
			object = (ResultSetWrappingSqlRowSet) jdbcTemplate.query(
					Query2, new Object[] {  },new SqlRowSetResultSetExtractor());
			rs = object.getResultSet();
			}
			while(rs.next())
			{
				//Date dt=formatter.parse(rs.getString("OLDEST_LOAN"));
				PnpReportDomain pnpdomain = new PnpReportDomain();
				pnpdomain.setDistrict(rs.getString("DISTRICT"));
				pnpdomain.setPincode(rs.getString("PIN_CODE"));
				pnpdomain.setStatecode(rs.getString("STATE_CODE"));
				pnpdomain.setTotalmfis(rs.getString("TOTAL_MFIS"));
				pnpdomain.setTotal_act_mfi(rs.getString("TOTAL_ACTIV_MFI"));
				pnpdomain.setTot_center(rs.getString("TOTAL_CENTERS"));
				pnpdomain.setTot_borowers(rs.getString("TOTAL_BORROWERS"));
				pnpdomain.setTot_act_borowers(rs.getString("TOTAL_ACTIV_BORROWERS"));
				pnpdomain.setTot_overdue_borrowers(rs.getString("TOTAL_OVERDUE_BORROWERS"));
				pnpdomain.setTot_active_loans(rs.getString("TOTAL_ACTIV_LOANS"));
				pnpdomain.setTot_active_dis_amnt(rs.getString("TOTAL_ACTIV_DISBURSED_AMOUNT"));
				pnpdomain.setTot_active_out_amnt(rs.getString("TOTAL_ACTIV_OUTSTANDING_AMOUNT"));
				pnpdomain.setTot_overdue_amnt(rs.getString("TOTAL_OVERDUE_AMOUNT"));
				pnpdomain.setAvg_loan(rs.getString("AVG_LOAN"));
				pnpdomain.setTotal_closed_loan(rs.getString("TOTAL_CLOSED_LOANS"));
				pnpdomain.setOldest_loan(rs.getString("OLDEST_LOAN"));
				pnpdomain.setTotal_loan_overdue(rs.getString("TOTAL_LOANS_OVERDUE"));
				pnpdomain.setTotal_loan_dpd_0(rs.getString("TOTAL_LOAN_DPD_0"));
				pnpdomain.setTotal_loan_dpd_1_30(rs.getString("TOTAL_LOAN_DPD_1_30"));
				pnpdomain.setTotal_loan_dpd_31_60(rs.getString("TOTAL_LOAN_DPD_31_60"));
				pnpdomain.setTotal_loan_dpd_61_90(rs.getString("TOTAL_LOAN_DPD_61_90"));
				pnpdomain.setPortfolio_overdue(rs.getString("PORTFOLIO_OVERDUE"));
				pnpdomain.setPortfolio_overdue_dpd_0(rs.getString("PORTFOLIO_OVERDUE_DPD_0"));
				pnpdomain.setPortfolio_overdue_dpd_1_30(rs.getString("PORTFOLIO_OVERDUE_DPD_1_30"));
				pnpdomain.setPortfolio_overdue_dpd_31_60(rs.getString("PORTFOLIO_OVERDUE_DPD_31_60"));
				pnpdomain.setPortfolio_overdue_dpd_61_90(rs.getString("PORTFOLIO_OVERDUE_DPD_61_90"));
				pnpdomain.setTot_write_off_loan(rs.getString("TOTAL_WRITE_OFF_LOANS"));
				pnpdomain.setTot_write_off_amnt(rs.getString("TOTAL_WRITE_OFF_AMT"));
				pnpdomain.setBorrow_in_ln_cycle_1(rs.getString("BORRWER_IN_LN_CYCLE_1"));
				pnpdomain.setBorrow_in_ln_cycle_2(rs.getString("BORRWER_IN_LN_CYCLE_2"));
				pnpdomain.setBorrow_in_ln_cycle_3_grtr(rs.getString("BORRWER_IN_LN_CYCLE_3_GRTR"));
				pnpdomain.setTot_ind_ln(rs.getString("TOTAL_IND_LN"));
				pnpdomain.setTot_ind_overdue_ln(rs.getString("TOTAL_IND_OVERDUE_LN"));
				pnpdomain.setInd_ln_overdue_amnt(rs.getString("IND_LN_OVERDUE_AMT"));
				pnpdomain.setTot_grp_ln(rs.getString("TOTAL_GROUP_LN"));
				pnpdomain.setTot_grp_overdue_ln(rs.getString("TOTAL_GROUP_OVERDUE_LN"));
				pnpdomain.setGrp_ln_overdue_amnt(rs.getString("GROUP_LN_OVERDUE_AMT"));
				pnpdomain.setBorrowers(rs.getString("BORROWERS"));
				pnpdomain.setBorrowers_na(rs.getString("BORROWER_NA"));
				pnpdomain.setBorrowers_0_5k(rs.getString("BORROWER_0_5K"));
				pnpdomain.setBorrowers_5k_10k(rs.getString("BORROWER_5K_10K"));
				pnpdomain.setBorrowers_10k_15k(rs.getString("BORROWER_10K_15K"));
				pnpdomain.setBorrowers_15k_50k(rs.getString("BORROWER_15K_50K"));
				pnpdomain.setBorrowers_50k_1lac(rs.getString("BORROWER_50K_1LACS"));
				pnpdomain.setBorrowers_grt_1lac(rs.getString("BORROWER_GRTR_1LACS"));
				pnpdomain.setInstlmnt_amnt(rs.getString("INSTALLMENT_AMT"));
				pnpdomain.setInstlmnt_0_6_0_15k(rs.getString("INSTALL_0_6_0_15K"));
				pnpdomain.setInstlmnt_0_6_15k_35k(rs.getString("INSTALL_0_6_15K_35K"));
				pnpdomain.setInstlmnt_0_6_35k_50k(rs.getString("INSTALL_0_6_35K_50K"));
				pnpdomain.setInstlmnt_0_6_grt_50k(rs.getString("INSTALL_0_6_GRTR_50K"));
				pnpdomain.setInstlmnt_7_12_0_15k(rs.getString("INSTALL_7_12_0_15K"));
				pnpdomain.setInstlmnt_7_12_15k_35k(rs.getString("INSTALL_7_12_15K_35K"));
				pnpdomain.setInstlmnt_7_12_35k_50k(rs.getString("INSTALL_7_12_35K_50K"));
				pnpdomain.setInstlmnt_7_12_grt_50k(rs.getString("INSTALL_7_12_GRTR_50K"));
				pnpdomain.setInstlmnt_13_24_0_15k(rs.getString("INSTALL_13_24_0_15K"));
				pnpdomain.setInstlmnt_13_24_15k_35k(rs.getString("INSTALL_13_24_15K_35K"));
				pnpdomain.setInstlmnt_13_24_35k_50k(rs.getString("INSTALL_13_24_35K_50K"));
				pnpdomain.setInstlmnt_13_24_grt_50k(rs.getString("INSTALL_13_24_GRTR_50K"));
				pnpdomain.setInstlmnt_grtr24_0_15k(rs.getString("INSTALL_GRTR24_0_15K"));
				pnpdomain.setInstlmnt_grtr24_15k_35k(rs.getString("INSTALL_GRTR24_15K_35K"));
				pnpdomain.setInstlmnt_grtr24_35k_50k(rs.getString("INSTALL_GRTR24_35K_50K"));
				pnpdomain.setInstlmnt_grtr24_grtr_50k(rs.getString("INSTALL_GRTR24_GRTR_50K"));
				pnpdomain.setLn_cycle(rs.getString("LN_CYCLE"));
				pnpdomain.setLn_1_0_15k(rs.getString("LN_1_0_15K"));
				pnpdomain.setLn_1_15k_35k(rs.getString("LN_1_15K_35K"));
				pnpdomain.setLn_1_35k_50k(rs.getString("LN_1_35K_50K"));
				pnpdomain.setLn_1_grtr_50k(rs.getString("LN_1_GRTR_50K"));
				pnpdomain.setLn_2_0_15k(rs.getString("LN_2_0_15K"));
				pnpdomain.setLn_2_15k_35k(rs.getString("LN_2_15K_35K"));
				pnpdomain.setLn_2_35k_50k(rs.getString("LN_2_35K_50K"));
				pnpdomain.setLn_2_grtr_50k(rs.getString("LN_2_GRTR_50K"));
				pnpdomain.setLn_gtrt3_0_15k(rs.getString("LN_GRTR3_0_15K"));
				pnpdomain.setLn_grtr3_15k_35k(rs.getString("LN_GRTR3_15K_35K"));
				pnpdomain.setLn_grtr3_35k_50k(rs.getString("LN_GRTR3_35K_50K"));
				pnpdomain.setLn_grtr3_grtr_50k(rs.getString("LN_GRTR3_GRTR_50K"));
				pnpdomain.setOverlap(rs.getString("OVERLAP"));
				pnpdomain.setOut_of_complince(rs.getString("OUT_OF_COMPLIANCE"));
				pnpdomain.setmFI2(rs.getString("MFI2"));
				pnpdomain.setmFI3(rs.getString("MFI3"));
				pnpdomain.setmFI4(rs.getString("MFI4"));
				pnpdomain.setNo_of_defualts(rs.getString("NO_OF_DEFAULTS"));
				pnpdomain.setMfi_grt_4(rs.getString("MFI_GRTR_4"));
				pnpdomain.setLn_grt_50k(rs.getString("LN_GRTR_50K"));
				pnpdomain.setLoan_purpose(rs.getString("LOAN_PURPOSE"));
				pnpdomain.setLn_purpose_na(rs.getString("LN_PURPOSE_NA"));
				pnpdomain.setLn_purpose_income(rs.getString("LN_PURPOSE_INCOME"));
				pnpdomain.setLn_purpose_edu(rs.getString("LN_PURPOSE_EDU"));
				pnpdomain.setLn_purpose_house(rs.getString("LN_PURPOSE_HOUSE"));
				pnpdomain.setLn_purpose_auto(rs.getString("LN_PURPOSE_AUTOMOBILE"));
				pnpdomain.setLn_purpose_realestate(rs.getString("LN_PURPOSE_REALESTATE"));
				pnpdomain.setLn_purpose_others(rs.getString("LN_PURPOSE_OTHERS"));
				pnpdomain.setOccupation(rs.getString("OCCUPATION"));
				pnpdomain.setOccupation_na(rs.getString("OCCUPATION_NA"));
				pnpdomain.setOccupation_agri(rs.getString("OCCUPATION_AGRI"));
				pnpdomain.setOccupation_contract_emp(rs.getString("OCCUPATION_CONTRACT_EMP"));
				pnpdomain.setOccupation_self_emp(rs.getString("OCCUPATION_SELF_EMP"));
				pnpdomain.setOccupation_emp(rs.getString("OCCUPATION_EMP"));
				pnpdomain.setOccupation_others(rs.getString("OCCUPATION_OTHERS"));
				pnpdomain.setTotal_loan_dpd_current(rs.getString("TOTAL_LOAN_DPD_CURRENT"));
				pnpdomain.setTotal_loan_dpd_91_180(rs.getString("TOTAL_LOAN_DPD_91_180"));
				pnpdomain.setTotal_loan_dpd_grtr180(rs.getString("TOTAL_LOAN_DPD_GRTR180"));
				pnpdomain.setAmount_overdue(rs.getString("AMOUNT_OVERDUE"));
				pnpdomain.setAmount_overdue_dpd_0(rs.getString("AMOUNT_OVERDUE_DPD_0"));
				pnpdomain.setAmount_overdue_dpd_1_30(rs.getString("AMOUNT_OVERDUE_DPD_1_30"));
				pnpdomain.setAmount_overdue_dpd_31_60(rs.getString("AMOUNT_OVERDUE_DPD_31_60"));
				pnpdomain.setAmount_overdue_dpd_61_90(rs.getString("AMOUNT_OVERDUE_DPD_61_90"));
				pnpdomain.setAmount_overdue_dpd_91_180(rs.getString("AMOUNT_OVERDUE_DPD_91_180"));
				pnpdomain.setAmount_overdue_dpd_grtr180(rs.getString("AMOUNT_OVERDUE_DPD_GRTR180"));
				pnpdomain.setPortfolio_overdue_dpd_current(rs.getString("PORTFOLIO_OVERDUE_DPD_CURRENT"));
				pnpdomain.setPortfolio_overdue_dpd_91_180(rs.getString("PORTFOLIO_OVERDUE_DPD_91_180"));
				pnpdomain.setPortfolio_overdue_dpd_grtr180(rs.getString("PORTFOLIO_OVERDUE_DPD_GRTR180"));
				pnpdomain.setTotal_shg_ln(rs.getString("TOTAL_SHG_LN"));
				pnpdomain.setTotal_shg_overdue_ln(rs.getString("TOTAL_SHG_OVERDUE_LN"));
				pnpdomain.setShg_ln_overdue_amt(rs.getString("SHG_LN_OVERDUE_AMT"));
				pnpdataList.add(pnpdomain);
			}
			
			if(pstmt!=null)
			pstmt.close();
			System.out.println("Requested Pincode Saved Sucessfully");
			//con.commit();
			

			
		}
		catch (SQLException se)
	    {
		      se.printStackTrace();
		      con.rollback();
		      if (1 == se.getErrorCode()) {
		    	  Trace trace = new Trace(getClass(), METHODNAME);
				throw new UniqueKeyConstraintViolationException(
		          trace, 
		          "Already Registered Pincode:",validpinrqst[i]);
		      }
		      LOGGER.error("Exception" + se.getMessage());
		      Trace trace = new Trace(getClass(), METHODNAME);
		      throw new PNPException(trace, 
		        "Error while register pincode rqst information", 
		        se);
		    }
		catch (Exception e) {
			e.printStackTrace();
			con.rollback();
			throw  new Exception("Error While Inserting Data");
		}
		/*finally{
			if(con!=null)
			con.close();
		}*/
		return pnpdataList;
		
	}

	
	public String exctractpricefordetails_(String reg_id, String regcustid,String prodId,String pincodes) throws Exception {
		
		String METHODNAME = "exctractpricefordetails_()";
		Connection con = null;
		
		String price=null;
		String pinrqst[]=null;
		int pnpcnt=0;
		int totvol=0;
		String flag=null;
		String prodprice = null;
		String fixPrice=null;
		int fixcnt=0;
		Date prddt=null;
		Date prdfrmdt=null;
		if(StringUtils.isNotBlank(pincodes))
			pinrqst=StringUtils.split(pincodes, "|");
		
		try{
			int trialpd = 0;
			Date tptodate = null;
			Date tpfromdt=null;
			String sysdate=null;
			String tpstatus=null;
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			SimpleDateFormat dateFormat1 = new SimpleDateFormat("dd-MMM-yy");
			Date date = new Date();
			Date sysdt=date;
			sysdate=dateFormat.format(sysdt);
			
			
			Date finalsysdate = dateFormat.parse(sysdate);
			con = getConnection();
			PreparedStatement pstmt = null;
				String Query="select TRIAL_PERIOD,TO_DATE(TO_DATE,'dd-mm-yyyy') as TO_DATE,TO_DATE(FROM_DATE,'dd-mm-yyyy') as FROM_DATE from Hm_Trial_Period_Tbl where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
				String QuerySts="select STATUS from Hm_Trial_Period_Tbl where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"'";
				pstmt=con.prepareStatement(QuerySts);
				ResultSet rs1 = pstmt.executeQuery();
				if(rs1.next())
				{
					tpstatus=rs1.getString("STATUS");
				}
				
				if(StringUtils.isBlank(tpstatus) || StringUtils.equalsIgnoreCase(tpstatus, "002"))
				{

					/*String flag=null;
					String prodprice = null;
					String fixPrice=null;
					Date prddt=null;*/
					String Queryforflag="select TO_DATE(VALID_FROM,'dd-mm-yyyy') as VALID_FROM,FIXED_NUMBER_OF_REQUEST,FIXED_FLAG,PRICE,FIXED_PRICE,TO_DATE(VALID_UPTO,'dd-mm-yyyy') as VALID_UPTO from Hm_Product_Access where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
					pstmt=con.prepareStatement(Queryforflag);
					ResultSet rss = pstmt.executeQuery();
					while (rss.next()) {
						flag=rss.getString("FIXED_FLAG");
						prodprice=rss.getString("PRICE");
						fixPrice=rss.getString("FIXED_PRICE");
						prddt=rss.getDate("VALID_UPTO");
						fixcnt=rss.getInt("FIXED_NUMBER_OF_REQUEST");
						prdfrmdt=rss.getDate("VALID_FROM");
					}
					
					if(StringUtils.equalsIgnoreCase(flag, "0") )
					{
						price=prodprice;
					}
					else if(StringUtils.equalsIgnoreCase(flag, "1"))			//if fix price date expired it will take base price as price
					{
						if((finalsysdate.after(prdfrmdt) || finalsysdate.equals(prdfrmdt)) && (finalsysdate.before(prddt) || finalsysdate.equals(prddt)))
						{
						String Query3="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request " +
								"Where REG_CUST_ID='"+regcustid+"' and PINOCDE_RESPONSE=1 and " +
								"PRICE="+fixPrice+" and trunc(Request_Date) between('"+dateFormat1.format(prdfrmdt)+"') and ('"+dateFormat1.format(prddt)+"')";;
						pstmt=con.prepareStatement(Query3);
						ResultSet rsfix = pstmt.executeQuery();
						
						while (rsfix.next()) {
							pnpcnt=rsfix.getInt("CNT");
						}
						int fixfinalcnt=fixcnt-pnpcnt;
						if(finalsysdate.after(prddt))
						{
							fixfinalcnt=0;
						}
						if((finalsysdate.before(prddt)||finalsysdate.equals(prddt))  && pnpcnt<fixcnt && fixfinalcnt>=pinrqst.length)
							price=fixPrice;
							else if(fixfinalcnt<pinrqst.length)
								return "fixexp"+"|"+prodprice+"|"+fixPrice+"|"+fixfinalcnt;	
						}
						else
						{
							System.out.println("Fix Product Access on if Sydate is between Fix From and To Date.");
							price=prodprice;
						}
					}
				//}
			
				}
				
				pstmt=con.prepareStatement(Query);
				ResultSet rs = pstmt.executeQuery();
				
				if (rs.next()) {
					trialpd=rs.getInt("TRIAL_PERIOD");
					tptodate=rs.getDate("TO_DATE");
					tpfromdt=rs.getDate("FROM_DATE");
					//return price;
				}
				/*if(tptodate!=null && tpfromdt!=null)
				{
				if((finalsysdate.after(tpfromdt)||finalsysdate.equals(tpfromdt)) && (finalsysdate.before(tptodate)||finalsysdate.equals(tptodate)))
				{
					System.out.println("Trial Period on if Sydate is between Trial Period From and To Date.");
					trialpd=1;
				}
				else
				{
					trialpd=0;
				}
				}*/
				if(trialpd==1 && !finalsysdate.before(tpfromdt))
				{
					if((finalsysdate.after(tpfromdt)||finalsysdate.equals(tpfromdt)) && (finalsysdate.before(tptodate)||finalsysdate.equals(tptodate)))			//if trial period expired it gives msg. and update TRIAL_PERIOD=0 and price access from product access form
					{
						String Query1="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request Where REG_CUST_ID='"+regcustid+"' " +
								"and PINOCDE_RESPONSE=1 and PRICE=0 and trunc(Request_Date) between('"+dateFormat1.format(tpfromdt)+"') and ('"+dateFormat1.format(tptodate)+"')";
						pstmt=con.prepareStatement(Query1);
						ResultSet rsvol = pstmt.executeQuery();
						
						while (rsvol.next()) {
							pnpcnt=rsvol.getInt("CNT");
						}
						System.out.println("Total PNP Count aleready rqsted: "+pnpcnt);
						
						String Query2="Select VOLUME From hm_trial_period_tbl Where REG_CUST_ID='"+regcustid+"' and Product_id='"+prodId+"'";
						pstmt=con.prepareStatement(Query2);
						ResultSet rss = pstmt.executeQuery();
						
						while (rss.next()) {
							totvol=rss.getInt("VOLUME");
						}
						System.out.println("Total Volume in Trial Period: "+totvol);
						int finalcnt=totvol-pnpcnt;
						System.out.println("Total Final Cnt: "+finalcnt);
						if(totvol>=pnpcnt)
						{
							if(finalcnt>=pinrqst.length)
							price="0";
							else
							{
								
								 if(finalcnt<=pinrqst.length)
								{
									String Queryforflag="select TO_DATE(VALID_FROM,'dd-mm-yyyy') as VALID_FROM,FIXED_NUMBER_OF_REQUEST,FIXED_FLAG,PRICE,FIXED_PRICE,TO_DATE(VALID_UPTO,'dd-mm-yyyy') as VALID_UPTO from Hm_Product_Access where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
									pstmt=con.prepareStatement(Queryforflag);
									ResultSet rsss = pstmt.executeQuery();
									while (rsss.next()) {
										flag=rsss.getString("FIXED_FLAG");
										prodprice=rsss.getString("PRICE");
										fixPrice=rsss.getString("FIXED_PRICE");
										prddt=rsss.getDate("VALID_UPTO");
										prdfrmdt=rsss.getDate("VALID_FROM");
										fixcnt=rsss.getInt("FIXED_NUMBER_OF_REQUEST");
										
									}
									if(StringUtils.equalsIgnoreCase(flag, "0"))
									{
										price=prodprice;
									}
									else if(StringUtils.equalsIgnoreCase(flag, "1"))			//if fix price date expired it will take base price as price
									{
										if((finalsysdate.after(prdfrmdt) || finalsysdate.equals(prdfrmdt))&& (finalsysdate.before(prddt) || finalsysdate.equals(prddt)))
										{
										String Query3="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request " +
												"Where REG_CUST_ID='"+regcustid+"' and PINOCDE_RESPONSE=1 and " +
												"PRICE="+fixPrice+" and trunc(Request_Date) between('"+dateFormat1.format(prdfrmdt)+"') and ('"+dateFormat1.format(prddt)+"')";
										pstmt=con.prepareStatement(Query3);
										ResultSet rsfix = pstmt.executeQuery();
										
										while (rsfix.next()) {
											pnpcnt=rsfix.getInt("CNT");
										}
										int fixfinalcnt=fixcnt-pnpcnt;
										if(finalsysdate.after(prddt))
										{
											fixfinalcnt=0;
										}
										if((finalsysdate.before(prddt)||finalsysdate.equals(prddt))  && pnpcnt<fixcnt && fixfinalcnt>=pinrqst.length)
										price=fixPrice;
										else if(fixfinalcnt<pinrqst.length)
											return "fixexp"+"|"+prodprice+"|"+fixPrice+"|"+fixfinalcnt+"|"+finalcnt;	
										}
										else
										{
											System.out.println("Fix Product Access on if Sydate is between Fix From and To Date.");
											price=prodprice;
										}
									}
									return "volexp"+"|"+finalcnt+"|"+price;
									
								}
							}
							
						}
						else
						{
							
							pstmt = con.prepareStatement("UPDATE HM_TRIAL_PERIOD_TBL SET TRIAL_PERIOD=0 WHERE REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS='' ");
							pstmt.executeUpdate();
							pstmt.close();
							
							String Queryforflag="select TO_DATE(VALID_FROM,'dd-mm-yyyy') as VALID_FROM,FIXED_NUMBER_OF_REQUEST,FIXED_FLAG,PRICE,FIXED_PRICE,TO_DATE(VALID_UPTO,'dd-mm-yyyy') as VALID_UPTO from Hm_Product_Access where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
							pstmt=con.prepareStatement(Queryforflag);
							ResultSet rsss = pstmt.executeQuery();
							while (rsss.next()) {
								flag=rsss.getString("FIXED_FLAG");
								prodprice=rsss.getString("PRICE");
								fixPrice=rsss.getString("FIXED_PRICE");
								prddt=rsss.getDate("VALID_UPTO");
								fixcnt=rsss.getInt("FIXED_NUMBER_OF_REQUEST");
								prdfrmdt=rsss.getDate("VALID_FROM");
							}
							if(StringUtils.equalsIgnoreCase(flag, "0"))
							{
								price=prodprice;
							}
							else if(StringUtils.equalsIgnoreCase(flag, "1"))			//if fix price date expired it will take base price as price
							{
								if((finalsysdate.after(prdfrmdt) || finalsysdate.equals(prdfrmdt))&& (finalsysdate.before(prddt) || finalsysdate.equals(prddt)))
								{
								String Query3="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request " +
										"Where REG_CUST_ID='"+regcustid+"' and PINOCDE_RESPONSE=1 and " +
												"PRICE="+fixPrice+" and trunc(Request_Date) between('"+dateFormat1.format(prdfrmdt)+"') and ('"+dateFormat1.format(prddt)+"')";
								pstmt=con.prepareStatement(Query3);
								ResultSet rsfix = pstmt.executeQuery();
								
								while (rsfix.next()) {
									pnpcnt=rsfix.getInt("CNT");
								}
								int fixfinalcnt=fixcnt-pnpcnt;
								if(finalsysdate.after(prddt))
								{
									fixfinalcnt=0;
								}
								if((finalsysdate.before(prddt)||finalsysdate.equals(prddt))  && pnpcnt<fixcnt && fixfinalcnt>=pinrqst.length)
									price=fixPrice;
									else if(fixfinalcnt<pinrqst.length)
										return "fixexp"+"|"+prodprice+"|"+fixPrice+"|"+fixfinalcnt+"|"+finalcnt;	
								}
								else
								{
									System.out.println("Fix Product Access on if Sydate is between Fix From and To Date.");
									price=prodprice;
								}
							}
							return "volexp "+"|"+finalcnt+"|"+price;
							//return "volexp "+"|"+finalcnt;
							
						}
					}
						
					else
					{
						pstmt = con.prepareStatement("UPDATE HM_TRIAL_PERIOD_TBL SET TRIAL_PERIOD=0 WHERE REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001");
					pstmt.executeUpdate();
					pstmt.close();	
					//return "expired";

					/*String flag=null;
					String prodprice = null;
					String fixPrice=null;
					Date prddt=null;*/
					String Queryforflag="select TO_DATE(VALID_FROM,'dd-mm-yyyy') as VALID_FROM,FIXED_NUMBER_OF_REQUEST,FIXED_FLAG,PRICE,FIXED_PRICE,TO_DATE(VALID_UPTO,'dd-mm-yyyy') as VALID_UPTO from Hm_Product_Access where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
					pstmt=con.prepareStatement(Queryforflag);
					ResultSet rss = pstmt.executeQuery();
					while (rss.next()) {
						flag=rss.getString("FIXED_FLAG");
						prodprice=rss.getString("PRICE");
						fixPrice=rss.getString("FIXED_PRICE");
						prddt=rss.getDate("VALID_UPTO");
						fixcnt=rss.getInt("FIXED_NUMBER_OF_REQUEST");
						prdfrmdt=rss.getDate("VALID_FROM");
					}
					
					if(StringUtils.equalsIgnoreCase(flag, "0") )
					{
						price=prodprice;
					}
					else if(StringUtils.equalsIgnoreCase(flag, "1"))			//if fix price date expired it will take base price as price
					{
						if((finalsysdate.after(prdfrmdt) || finalsysdate.equals(prdfrmdt)) && (finalsysdate.before(prddt) || finalsysdate.equals(prddt)))
						{
						String Query3="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request " +
								"Where REG_CUST_ID='"+regcustid+"' and PINOCDE_RESPONSE=1 and " +
								"PRICE="+fixPrice+" and trunc(Request_Date) between('"+dateFormat1.format(prdfrmdt)+"') and ('"+dateFormat1.format(prddt)+"')";;
						pstmt=con.prepareStatement(Query3);
						ResultSet rsfix = pstmt.executeQuery();
						
						while (rsfix.next()) {
							pnpcnt=rsfix.getInt("CNT");
						}
						int fixfinalcnt=fixcnt-pnpcnt;
						if(finalsysdate.after(prddt))
						{
							fixfinalcnt=0;
						}
						if((finalsysdate.before(prddt)||finalsysdate.equals(prddt))  && pnpcnt<fixcnt && fixfinalcnt>=pinrqst.length)
							price=fixPrice;
							else if(fixfinalcnt<pinrqst.length)
								return "fixexp"+"|"+prodprice+"|"+fixPrice+"|"+fixfinalcnt;	
						}
						else
						{
							System.out.println("Fix Product Access on if Sydate is between Fix From and To Date.");
							price=prodprice;
						}
					}
				//}
			
					}
					
					
					
				}
				else if(trialpd==1)
				{

					/*String flag=null;
					String prodprice = null;
					String fixPrice=null;
					Date prddt=null;*/
					String Queryforflag="select TO_DATE(VALID_FROM,'dd-mm-yyyy') as VALID_FROM,FIXED_NUMBER_OF_REQUEST,FIXED_FLAG,PRICE,FIXED_PRICE,TO_DATE(VALID_UPTO,'dd-mm-yyyy') as VALID_UPTO from Hm_Product_Access where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
					pstmt=con.prepareStatement(Queryforflag);
					ResultSet rss = pstmt.executeQuery();
					while (rss.next()) {
						flag=rss.getString("FIXED_FLAG");
						prodprice=rss.getString("PRICE");
						fixPrice=rss.getString("FIXED_PRICE");
						prddt=rss.getDate("VALID_UPTO");
						fixcnt=rss.getInt("FIXED_NUMBER_OF_REQUEST");
						prdfrmdt=rss.getDate("VALID_FROM");
					}
					
					if(StringUtils.equalsIgnoreCase(flag, "0") )
					{
						price=prodprice;
					}
					else if(StringUtils.equalsIgnoreCase(flag, "1"))			//if fix price date expired it will take base price as price
					{
						if((finalsysdate.after(prdfrmdt) || finalsysdate.equals(prdfrmdt)) && (finalsysdate.before(prddt) || finalsysdate.equals(prddt)))
						{
						String Query3="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request " +
								"Where REG_CUST_ID='"+regcustid+"' and PINOCDE_RESPONSE=1 and " +
								"PRICE="+fixPrice+" and trunc(Request_Date) between('"+dateFormat1.format(prdfrmdt)+"') and ('"+dateFormat1.format(prddt)+"')";;
						pstmt=con.prepareStatement(Query3);
						ResultSet rsfix = pstmt.executeQuery();
						
						while (rsfix.next()) {
							pnpcnt=rsfix.getInt("CNT");
						}
						int fixfinalcnt=fixcnt-pnpcnt;
						if(finalsysdate.after(prddt))
						{
							fixfinalcnt=0;
						}
						if((finalsysdate.before(prddt)||finalsysdate.equals(prddt))  && pnpcnt<fixcnt && fixfinalcnt>=pinrqst.length)
							price=fixPrice;
							else if(fixfinalcnt<pinrqst.length)
								return "fixexp"+"|"+prodprice+"|"+fixPrice+"|"+fixfinalcnt;	
						}
						else
						{
							System.out.println("Fix Product Access on if Sydate is between Fix From and To Date.");
							price=prodprice;
						}
					}
				//}
			
				}
				
					else if(trialpd==0 || rs==null || finalsysdate.before(tpfromdt))
					{
						/*String flag=null;
						String prodprice = null;
						String fixPrice=null;
						Date prddt=null;*/
						String Queryforflag="select TO_DATE(VALID_FROM,'dd-mm-yyyy') as VALID_FROM,FIXED_NUMBER_OF_REQUEST,FIXED_FLAG,PRICE,FIXED_PRICE,TO_DATE(VALID_UPTO,'dd-mm-yyyy') as VALID_UPTO from Hm_Product_Access where REG_CUST_ID='"+regcustid+"' and PRODUCT_ID='"+prodId+"' and STATUS=001";
						pstmt=con.prepareStatement(Queryforflag);
						ResultSet rss = pstmt.executeQuery();
						while (rss.next()) {
							flag=rss.getString("FIXED_FLAG");
							prodprice=rss.getString("PRICE");
							fixPrice=rss.getString("FIXED_PRICE");
							prddt=rss.getDate("VALID_UPTO");
							fixcnt=rss.getInt("FIXED_NUMBER_OF_REQUEST");
							prdfrmdt=rss.getDate("VALID_FROM");
						}
						
						if(StringUtils.equalsIgnoreCase(flag, "0") )
						{
							price=prodprice;
						}
						else if(StringUtils.equalsIgnoreCase(flag, "1"))			//if fix price date expired it will take base price as price
						{
							if((finalsysdate.after(prdfrmdt) || finalsysdate.equals(prdfrmdt)) && (finalsysdate.before(prddt) || finalsysdate.equals(prddt)))
							{
							String Query3="Select Count(Pinocde_Request) as CNT From Hm_Pincode_Request " +
									"Where REG_CUST_ID='"+regcustid+"' and PINOCDE_RESPONSE=1 and " +
									"PRICE="+fixPrice+" and trunc(Request_Date) between('"+dateFormat1.format(prdfrmdt)+"') and ('"+dateFormat1.format(prddt)+"')";;
							pstmt=con.prepareStatement(Query3);
							ResultSet rsfix = pstmt.executeQuery();
							
							while (rsfix.next()) {
								pnpcnt=rsfix.getInt("CNT");
							}
							int fixfinalcnt=fixcnt-pnpcnt;
							if(finalsysdate.after(prddt))
							{
								fixfinalcnt=0;
							}
							if((finalsysdate.before(prddt)||finalsysdate.equals(prddt))  && pnpcnt<fixcnt && fixfinalcnt>=pinrqst.length)
								price=fixPrice;
								else if(fixfinalcnt<pinrqst.length)
									return "fixexp"+"|"+prodprice+"|"+fixPrice+"|"+fixfinalcnt;	
							}
							else
							{
								System.out.println("Fix Product Access on if Sydate is between Fix From and To Date.");
								price=prodprice;
							}
						}
					//}
				}
				
				
				
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw  new Exception("Error While Fetching Data");
		}
		finally{
			if(con!=null)
			con.close();
		}
		return price;
	}

	public String getdistcount_(String statename) throws PNPException {


		String METHODNAME = "getdistcount_()";
		String distcount=null;
		Connection con = null;
		Statement stmt = null;

		try {
			con = getConnection();
			stmt = con.createStatement();
			
			
	String Query="select Count(distinct (DISTRICT)) as distCount from hm_pin_pnp_test where STATE_CODE='"+statename+"'";
	     
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next()) {
				
				distcount=rs.getString("distCount");

			}

		} catch (SQLException se) {
			if (error) {
				LOGGER.error("Exception" + se.getMessage());
			}
			se.printStackTrace();
			Trace trace = new Trace(this.getClass(), METHODNAME);
			throw new PNPException(trace,
					"Error while  retriving District Count  List", se);
		}

		finally {
			if (con != null) {
				try {
					stmt.close();
					con.close();
				} catch (SQLException se) {
					if (error) {
						LOGGER.error("Exception" + se.getMessage());
					}
					
					throw new ConnectionNotFoundException(
							"Connection Not Found");
				}
			} else {
				if (debug) {
					LOGGER.debug("connection not open");
				}
			}
		}

		if (debug) {
			LOGGER.debug("Returning from " + METHODNAME + " in " + CLASSNAME);
		}
		return distcount;



}
	
	
	

}
